<html>
<?php include'common/head.php';?>
<body>
<?php include'common/nav.php';?>
  <section id="contentSection">
  <section id="contentSection">
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-8">
        <div class="left_content">
          <div class="single_page">
            <ol class="breadcrumb">
              <li><a href="../index.php">Home</a></li>
              
            </ol>
            <h1>'Kohli panicked while preparing for England tour'</h1>
            <div class="post_commentbox"> <a href="#"><i class="fa fa-user"></i>Sports</a> <span><i class="fa fa-calendar"></i></span> <a href="#"><i class="fa fa-tags"></i>Technology</a> </div>
            <div class="single_page_content"> <img class="img-center" src="../images/29.jpg" alt="">
    <p>
	<h3>A</h3> tough tour of England four years ago made Virat Kohli panicky while preparing for the upcoming series but former India captain Sourav Ganguly is happy that the star cricketer did not end up playing county cricket in his eagerness to be well-prepared.	
	<br/>
	<blockquote>“Kohli is a fantastic player. He will do well this time. I am happy that he did not play county cricket before the England series. I think he was eager to play county (ahead of the series) because he was panicky after not having a good tour last time around. He is too good a player to miss out this time,” Ganguly said.

Kohli's much-hyped stint at Surrey was eventually ruled out after he suffered a neck injury.</blockquote>
	Before departing to England earlier this week, the Indian skipper felt not playing county could be a blessing in disguise as a break from the game has refreshed him completely.

He has also moved on from what happened in England four years ago when he could only muster 134 runs in 10 Test innings at 13.40.

Kohli has been supremely successful in South Africa and Australia, making England a territory to conquer.

Ganguly thinks both captain and the team will do well in the five Test series.<br/>

“India's chances are bright but England are also in good form. It will be a closely contested series,” he reckoned.

Expressing his concerns on the health of the game, Ganguly said he<br/> was 'scared' after England amassed 481 runs in an ODI against Australia at Nottingham on June 19.

The record score also drew a negative reaction <br/>from Sachin Tendukar, who said bowling with two new balls in ODIs was a 'recipe for disaster'.

Ganguly fully concurred with Tendulkar, saying bowling with two new balls take reverse swing out of the equation.

“Yes two news balls do take reverse swing out of the <br/>picture because the ball doesn't get old enough to reverse," he said.

"Reverse swing is also dying because the grounds are a lot greener today. The balls don't get scuffed up enough. They don't get dry and rough on one side for the reverse to happen.”

Pressed further on the controversial subject, Ganguly questioned the rotation policy followed by teams like Australia.

“500 runs in 50 overs is terrible. Bowling has to find a way. I don't understand why the best bowlers don't play. Wasim (Akram) and Waqar (Younis) played ODIs and Tests all together, so did (Glenn) McGrath and (Brett) Lee and (Shaun) Pollock and (Allan) Donald. All played at the same time. I don't understand having a separate set <br/>of bowlers for Tests and ODIs," he said.

“It (481/6 in England) was a poor advert of cricket. Every over had three boundaries. You cannot have Mitchell Starc and Josh Hazlewood not play. So the best of players have to play. Nathan Lyon mostly plays Tests, doesn't play ODIs. Shane Warne played everything, so did Anil (Kumble) and (Muttiah) Muralitharan,” said the former <br/>inspirational skipper.
	
	</p>
             
            </div>
            <div class="social_link">
              <ul class="sociallink_nav">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
              </ul>
            </div>
            
          </div>
        </div>
      </div>
      <nav class="nav-slit"> <a class="prev" href="#"> <span class="icon-wrap"><i class="fa fa-angle-left"></i></span>
        <div>
          <h3>City Lights</h3>
          <img src="../images/post_img1.jpg" alt=""/> </div>
        </a> <a class="next" href="#"> <span class="icon-wrap"><i class="fa fa-angle-right"></i></span>
        <div>
          <h3>Street Hills</h3>
          <img src="../images/post_img1.jpg" alt=""/> </div>
        </a> </nav>
      <div class="col-lg-4 col-md-4 col-sm-4">
        <aside class="right_content">
          <?php include'common/popular.php';?>
          <div class="single_sidebar">
            <ul class="nav nav-tabs" role="tablist">
              <li role="presentation" class="active"><a href="#category" aria-controls="home" role="tab" data-toggle="tab">Category</a></li>
              <li role="presentation"><a href="#video" aria-controls="profile" role="tab" data-toggle="tab">Video</a></li>
            </ul>
            <div class="tab-content">
              <div role="tabpanel" class="tab-pane active" id="category">
                <ul>
                  <li class="cat-item"><a href="#">Sports</a></li>
                  <li class="cat-item"><a href="#">Fashion</a></li>
                  <li class="cat-item"><a href="#">Business</a></li>
                  <li class="cat-item"><a href="#">Technology</a></li>
                  <li class="cat-item"><a href="#">Games</a></li>
                  <li class="cat-item"><a href="#">Life &amp; Style</a></li>
                  <li class="cat-item"><a href="#">Photography</a></li>
                </ul>
              </div>
              <?php include'common/video.php';?>
            </div>
          </div>
         
          <div class="single_sidebar wow fadeInDown">
            <h2><span>Category Archive</span></h2>
            <select class="catgArchive">
              <option>Select Category</option>
              <option>Life styles</option>
              <option>Sports</option>
              <option>Technology</option>
              <option>Treads</option>
            </select>
          </div>
          <div class="single_sidebar wow fadeInDown">
            <h2><span>Links</span></h2>
            
          </div>
        </aside>
      </div>
    </div>
  </section>
  <?php include'common/footer.php';?>
</div>
<script src="../assets/js/jquery.min.js"></script> 
<script src="../assets/js/wow.min.js"></script> 
<script src="../assets/js/bootstrap.min.js"></script> 
<script src="../assets/js/slick.min.js"></script> 
<script src="../assets/js/jquery.li-scroller.1.0.js"></script> 
<script src="../assets/js/jquery.newsTicker.min.js"></script> 
<script src="../assets/js/jquery.fancybox.pack.js"></script> 
<script src="../assets/js/custom.js"></script>
</body>
</html>