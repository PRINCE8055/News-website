<html>
<?php include'common/head.php';?>
<body>
<?php include'common/nav.php';?>
  <section id="contentSection">
  <section id="contentSection">
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-8">
        <div class="left_content">
          <div class="single_page">
            <ol class="breadcrumb">
              <li><a href="../index.php">Home</a></li>
              
            </ol>
            <h1>World’s smallest computer device ‘Michigan Micro Mote’ created</h1>
            <div class="post_commentbox"> <a href="#"><i class="fa fa-user"></i>Technews</a> <span><i class="fa fa-calendar"></i></span> <a href="#"><i class="fa fa-tags"></i>Technology</a> </div>
            <div class="single_page_content"> <img class="img-center" src="../images/26.jpg" alt="">
    <p>
	One of the big challenges in building the device called Michigan Micro Mote was how to run at very low power when the system packaging had to be transparent.
	<br/>
	Scientists have developed the world’s smallest computer – a device that measures just 0.3 millimetres and could help find new ways to monitor and treat cancer. Previous systems, including the 2x2x4 millimetre Michigan Micro Mote, retain their programming and data even when they are not externally powered. Unplug a desktop computer, and its program and data are still there when it boots itself up once the power is back. However, these new microdevices lose all prior programming and data as soon as they lose power.
	
	<br/>
	“We are not sure if they should be called computers or not. It’s more of a matter of opinion whether they have the minimum functionality required,” said David Blaauw, a professor at the University of Michigan in the US, who led the development of the new system. In addition to the RAM and photovoltaics, the new computing devices have processors and wireless transmitters and receivers. Since they are too small to have conventional radio antennae, they receive and transmit data with visible light. A base station provides light for power and programming, and it receives the data.

Also Read: World’s most powerful supercomputer unveiled

One of the big challenges in building the device called Michigan Micro Mote was how to run at very low power when the system packaging had to be transparent. The light from the base station – and from the device’s own transmission LED – can induce currents in its tiny circuits. “We basically had to invent new ways of approaching circuit design that would be equally low power but could also tolerate light,” Blaauw said.

For example, that meant exchanging diodes, which can act like tiny solar cells, for switched capacitors. Another challenge was achieving high accuracy while running on low power, which makes many of the usual electrical signals (like charge, current and voltage) noisier.
	
	<br/>
	Designed as a precision temperature sensor, the new device converts temperatures into time intervals, defined with electronic pulses. The intervals are measured on-chip against a steady time interval sent by the base station and then converted into a temperature. As a result, the computer can report temperatures in minuscule regions – such as a cluster of cells – with an error of about 0.1 degrees Celsius.

The system is very flexible and could be reimagined for a variety of purposes, but the team chose precision temperature measurement, as some studies suggest that tumors run hotter than normal tissue, but the data isn’t solid enough for confidence on the issue. Temperature may also help in evaluating cancer treatments.

Also Read: IBM pits computer against human debaters

“Since the temperature sensor is small and biocompatible, we can implant it into a mouse and cancer cells grow around it,” said Gary Luker, a professor at University of Michigan. “We are using this temperature sensor to investigate variations in temperature within a tumor versus normal tissue and if we can use changes in temperature to determine success or failure of therapy,” Luker said. Researchers look forward to what purposes others will find for their latest microcomputing device.
	
	
	
	
	
	
	</p>
             
            </div>
            <div class="social_link">
              <ul class="sociallink_nav">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
              </ul>
            </div>
            
          </div>
        </div>
      </div>
      <nav class="nav-slit"> <a class="prev" href="#"> <span class="icon-wrap"><i class="fa fa-angle-left"></i></span>
        <div>
          <h3>City Lights</h3>
          <img src="../images/post_img1.jpg" alt=""/> </div>
        </a> <a class="next" href="#"> <span class="icon-wrap"><i class="fa fa-angle-right"></i></span>
        <div>
          <h3>Street Hills</h3>
          <img src="../images/post_img1.jpg" alt=""/> </div>
        </a> </nav>
      <div class="col-lg-4 col-md-4 col-sm-4">
        <aside class="right_content">
          <?php include'common/popular.php';?>
          <div class="single_sidebar">
            <ul class="nav nav-tabs" role="tablist">
              <li role="presentation" class="active"><a href="#category" aria-controls="home" role="tab" data-toggle="tab">Category</a></li>
              <li role="presentation"><a href="#video" aria-controls="profile" role="tab" data-toggle="tab">Video</a></li>
            </ul>
            <div class="tab-content">
              <div role="tabpanel" class="tab-pane active" id="category">
                <ul>
                  <li class="cat-item"><a href="#">Sports</a></li>
                  <li class="cat-item"><a href="#">Fashion</a></li>
                  <li class="cat-item"><a href="#">Business</a></li>
                  <li class="cat-item"><a href="#">Technology</a></li>
                  <li class="cat-item"><a href="#">Games</a></li>
                  <li class="cat-item"><a href="#">Life &amp; Style</a></li>
                  <li class="cat-item"><a href="#">Photography</a></li>
                </ul>
              </div>
              <?php include'common/video.php';?>
            </div>
          </div>
         
          <div class="single_sidebar wow fadeInDown">
            <h2><span>Category Archive</span></h2>
            <select class="catgArchive">
              <option>Select Category</option>
              <option>Life styles</option>
              <option>Sports</option>
              <option>Technology</option>
              <option>Treads</option>
            </select>
          </div>
          <div class="single_sidebar wow fadeInDown">
            <h2><span>Links</span></h2>
            
          </div>
        </aside>
      </div>
    </div>
  </section>
  <?php include'common/footer.php';?>
</div>
<script src="../assets/js/jquery.min.js"></script> 
<script src="../assets/js/wow.min.js"></script> 
<script src="../assets/js/bootstrap.min.js"></script> 
<script src="../assets/js/slick.min.js"></script> 
<script src="../assets/js/jquery.li-scroller.1.0.js"></script> 
<script src="../assets/js/jquery.newsTicker.min.js"></script> 
<script src="../assets/js/jquery.fancybox.pack.js"></script> 
<script src="../assets/js/custom.js"></script>
</body>
</html>