<html>
<?php include'common/head.php';?>
<body>
<?php include'common/nav.php';?>
  <section id="contentSection">
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-8">
        <div class="left_content">
          <div class="contact_area">
            <h2>Contact Us</h2>
            <p>if you have any query and if you want to giv feedback than write it here.we are here to provide you best and amazing news<br/>
            <br/>
            </p>
            <blockquote><h2>content writer:Nancy singh
            </h2><br/>
            <h2>website developer:Prince Raj</h2></blockquote>
            <form action="feed.php" method="POST" class="contact_form">
              <input class="form-control" type="text" name="name" placeholder="Name*">
              <input class="form-control" type="email" name="email" placeholder="Email*">
              <textarea class="form-control" cols="30" rows="10" name="message" placeholder="Message*"></textarea>
              <input type="submit" value="Send Message">
            </form>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-4 col-sm-4">
        <aside class="right_content">
          <?php include'common/popular.php';?>
        </aside>
      </div>
    </div>
  </section>
 <?php include'common/footer.php';?>
</div>
<script src="../assets/js/jquery.min.js"></script> 
<script src="../assets/js/wow.min.js"></script> 
<script src="../assets/js/bootstrap.min.js"></script> 
<script src="../assets/js/slick.min.js"></script> 
<script src="../assets/js/jquery.li-scroller.1.0.js"></script> 
<script src="../assets/js/jquery.newsTicker.min.js"></script> 
<script src="../assets/js/jquery.fancybox.pack.js"></script> 
<script src="../assets/js/custom.js"></script>
</body>
</html>