<html>
<?php include'common/head.php';?>
<body>
<?php include'common/nav.php';?>
  <section id="contentSection">
  <section id="contentSection">
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-8">
        <div class="left_content">
          <div class="single_page">
            <ol class="breadcrumb">
              <li><a href="../index.php">Home</a></li>
              <li><a href="#">Technology</a></li>
              <li class="active">Mobile</li>
            </ol>
            <h1>Fajita heist: Texas man sentenced to 50 years for stealing $1.2 million worth of food </h1>
            <div class="post_commentbox"> <a href="#"><i class="fa fa-user"></i>Hackingnews.com</a> <span><i class="fa fa-calendar"></i></span> <a href="#"><i class="fa fa-tags"></i>Technology</a> </div>
            <div class="single_page_content"> <img class="img-center" src="../images/th.jpg" alt="">
             <P>A Texas man who plead guilty to stealing more than $1.2 million in fajitas while acting as a public servant has been sentenced to 50 years in prison.</br>
			 Gilberto Escamilla, 53, was employed at the Darrel B. Hester Juvenile Detention Center in San Benito, Texas, until August 2017 — when it was discovered that he had been placing orders for fajitas using county funds and then selling them for his own profit since December 2008, according to Cameron County Court filings.

When sentenced on Friday, Escamilla was also served with the maximum fine of $10,000 on top of the $1,251,578.72 he was ordered to pay back for the cost of the fajitas, officials said.<br/>

According to The Brownsville Herald, Escamilla's scheme unraveled last August after a delivery driver with Labatt Food Service phoned the detention center to give kitchen employees a heads up that an 800-pound delivery of fajitas had arrived.

Employees immediately thought the delivery to be suspicious as minors at the detention center are not served fajitas, however the delivery driver insisted that had been delivering fajitas to the detention center's kitchen for the past nine years.

After being fired and arrested, Escamilla's house was searched by police, who found packages of the fajitas in his refrigerator.

"It was selfish. It started small and got bigger and out of control," Escamilla said during court testimony, according to the Herald. "It got to the point where I couldn't control it anymore."

Texas State District Judge J. Manuel Banales, who handed down the sentence, dismissed an additional theft charge as part of an earlier plea deal made by Escamilla.<br/> Because Escamilla stole more than $200,000 worth of goods, Texas law considers the crime to be a first degree felony and allows for a sentencing of up to 99 years in prison. It also allows for a more severe punishment<br/> if the defendant commits a crime while acting as a public servant.
			 </P>
 
              <button class="btn default-btn">Home</button>
              <button class="btn btn-red">Smartphone</button>
              <button class="btn btn-yellow">Computers</button>
              
             
            </div>
            <div class="social_link">
              <ul class="sociallink_nav">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
              </ul>
            </div>
            
          </div>
        </div>
      </div>
      <nav class="nav-slit"> <a class="prev" href="#"> <span class="icon-wrap"><i class="fa fa-angle-left"></i></span>
        <div>
          <h3>City Lights</h3>
          <img src="../images/post_img1.jpg" alt=""/> </div>
        </a> <a class="next" href="#"> <span class="icon-wrap"><i class="fa fa-angle-right"></i></span>
        <div>
          <h3>Street Hills</h3>
          <img src="../images/post_img1.jpg" alt=""/> </div>
        </a> </nav>
      <div class="col-lg-4 col-md-4 col-sm-4">
        <aside class="right_content">
          <?php include'common/popular.php';?>
          <div class="single_sidebar">
            <ul class="nav nav-tabs" role="tablist">
              <li role="presentation" class="active"><a href="#category" aria-controls="home" role="tab" data-toggle="tab">Category</a></li>
              <li role="presentation"><a href="#video" aria-controls="profile" role="tab" data-toggle="tab">Video</a></li>
            </ul>
            <div class="tab-content">
              <div role="tabpanel" class="tab-pane active" id="category">
                <ul>
                  <li class="cat-item"><a href="#">Sports</a></li>
                  <li class="cat-item"><a href="#">Fashion</a></li>
                  <li class="cat-item"><a href="#">Business</a></li>
                  <li class="cat-item"><a href="#">Technology</a></li>
                  <li class="cat-item"><a href="#">Games</a></li>
                  <li class="cat-item"><a href="#">Life &amp; Style</a></li>
                  <li class="cat-item"><a href="#">Photography</a></li>
                </ul>
              </div>
              <?php include'common/video.php';?>
            </div>
          </div>
         
          <div class="single_sidebar wow fadeInDown">
            <h2><span>Category Archive</span></h2>
            <select class="catgArchive">
              <option>Select Category</option>
              <option>Life styles</option>
              <option>Sports</option>
              <option>Technology</option>
              <option>Treads</option>
            </select>
          </div>
          <div class="single_sidebar wow fadeInDown">
            <h2><span>Links</span></h2>
            
          </div>
        </aside>
      </div>
    </div>
  </section>
  <?php include'common/footer.php';?>
</div>
<script src="../assets/js/jquery.min.js"></script> 
<script src="../assets/js/wow.min.js"></script> 
<script src="../assets/js/bootstrap.min.js"></script> 
<script src="../assets/js/slick.min.js"></script> 
<script src="../assets/js/jquery.li-scroller.1.0.js"></script> 
<script src="../assets/js/jquery.newsTicker.min.js"></script> 
<script src="../assets/js/jquery.fancybox.pack.js"></script> 
<script src="../assets/js/custom.js"></script>
</body>
</html>