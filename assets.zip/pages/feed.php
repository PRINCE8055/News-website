<?php
include_once 'dbConn.php';

$name = $_POST['name'];
$email = $_POST['email'];


$date=date("Y-m-d");
$time=date("h:i:sa");
$feedback = $_POST['message'];
$q=mysqli_query($con,"INSERT INTO feed VALUES  ( '$name', '$email' , '$feedback' , '$date' , '$time')")or die("error");
header("location:contact.php"); 



?>