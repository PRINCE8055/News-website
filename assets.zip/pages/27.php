<html>
<?php include'common/head.php';?>
<body>
<?php include'common/nav.php';?>
  <section id="contentSection">
  <section id="contentSection">
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-8">
        <div class="left_content">
          <div class="single_page">
            <ol class="breadcrumb">
              <li><a href="../index.php">Home</a></li>
              
            </ol>
            <h1>India stun Argentina, continue unbeaten run in Champions Trophy</h1>
            <div class="post_commentbox"> <a href="#"><i class="fa fa-user"></i>sports</a> <span><i class="fa fa-calendar"></i></span> <a href="#"><i class="fa fa-tags"></i>Technology</a> </div>
            <div class="single_page_content"> <img class="img-center" src="../images/27.jpg" alt="">
    <p>
	India continued their unbeaten run in the Champions Trophy hockey tournament and surprised Olympic champions Argentina 2-1 for a second consecutive win in the 37th and last edition of the prestigious tournament in Breda on Sunday.

<br/>
<blockquote><h3>India scored both their goals in the second quarter through Harmanpreet Singh (17th minute), who converted a penalty corner, and Mandeep Singh (28th).

World number two Argentina's lone goal came from the sticks of dragflciker Gonzalo Peillat, who scored from a set piece in the 30th minute.

India, eying their maiden Champions Trophy title, had earlier crushed bitter-rivals Pakistan 4-0 in their campaign opener on Saturrday.

India now sit atop the six-team standings with two wins from as many games.</h3></blockquote>

<br/>

The eight-time Olympic champions will take on world champions Australia in their next round robin match on June 27.

The team's new chief coach Harendra Singh couldn't have asked for a better start to his fourth stint with the senior national side. Harendra took over the reigns after swapping roles with Sjoerd Marijne, following India's dreadful Commonwealth Games campaign.

Coming into the tournament on the back of a disastrous campaign at the Gold Coast Games, where they finished a disappointing fourth, the Indians made their intentions clear early on by showcasing all-round, compact hockey in their opening two games.

The Indians carried on from where they left against Pakistan last night and produced a solid display in all departments of the game to get the better of their fancied rivals.

The defence, which was once India's perennial problem, yet again stole the show with a compact display, while the forwardline was up to the mark despite missing Ramandeep Singh owing to a knee injury suffered on Saturday.

The talismanic Sardar Singh, who played his 300th international game today, controlled the midfield and combined well with the forwardline to create opportunities.

Argentina, however, were quick to get off the blocks, securing three consecutive penalty corners in the first quarter, but the Indian defence stood tall to deny Peillat.

Next it was India's turn to earn a penalty corner in the 17th minute and Harmanpreet fired home with a low flick through the legs of Argentina goalkeeper Tomas Santiago.

Two minutes from half time, India doubled their lead through Mandeep but it was Dilpreet, who created the chance by brilliantly controlling a overhead long ball inside the circle and then setting it up for his striking colleague.

Argentina pulled one goal back just at the stroke of half time through Peillat's powerful strike to the top left corner of the Indian goal.

India got their second penalty corner seconds from half time but Harmanpreet failed this time.

After the change of ends, the Los Leones pressed hard and in the process earned their fifth penalty corner, but the Indian defence was up to the task.

Minutes later, Argentina custodian Santiago made a double save from a counterattack to deny Dilpreet and Mandeep.

In the final quarter, Varun Kumar made a goal-line save to deny Lucas Villa a chance to draw parity for Argentina.</p>
             
            </div>
            <div class="social_link">
              <ul class="sociallink_nav">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
              </ul>
            </div>
            
          </div>
        </div>
      </div>
      <nav class="nav-slit"> <a class="prev" href="#"> <span class="icon-wrap"><i class="fa fa-angle-left"></i></span>
        <div>
          <h3>City Lights</h3>
          <img src="../images/post_img1.jpg" alt=""/> </div>
        </a> <a class="next" href="#"> <span class="icon-wrap"><i class="fa fa-angle-right"></i></span>
        <div>
          <h3>Street Hills</h3>
          <img src="../images/post_img1.jpg" alt=""/> </div>
        </a> </nav>
      <div class="col-lg-4 col-md-4 col-sm-4">
        <aside class="right_content">
          <?php include'common/popular.php';?>
          <div class="single_sidebar">
            <ul class="nav nav-tabs" role="tablist">
              <li role="presentation" class="active"><a href="#category" aria-controls="home" role="tab" data-toggle="tab">Category</a></li>
              <li role="presentation"><a href="#video" aria-controls="profile" role="tab" data-toggle="tab">Video</a></li>
            </ul>
            <div class="tab-content">
              <div role="tabpanel" class="tab-pane active" id="category">
                <ul>
                  <li class="cat-item"><a href="#">Sports</a></li>
                  <li class="cat-item"><a href="#">Fashion</a></li>
                  <li class="cat-item"><a href="#">Business</a></li>
                  <li class="cat-item"><a href="#">Technology</a></li>
                  <li class="cat-item"><a href="#">Games</a></li>
                  <li class="cat-item"><a href="#">Life &amp; Style</a></li>
                  <li class="cat-item"><a href="#">Photography</a></li>
                </ul>
              </div>
              <?php include'common/video.php';?>
            </div>
          </div>
         
          <div class="single_sidebar wow fadeInDown">
            <h2><span>Category Archive</span></h2>
            <select class="catgArchive">
              <option>Select Category</option>
              <option>Life styles</option>
              <option>Sports</option>
              <option>Technology</option>
              <option>Treads</option>
            </select>
          </div>
          <div class="single_sidebar wow fadeInDown">
            <h2><span>Links</span></h2>
            
          </div>
        </aside>
      </div>
    </div>
  </section>
  <?php include'common/footer.php';?>
</div>
<script src="../assets/js/jquery.min.js"></script> 
<script src="../assets/js/wow.min.js"></script> 
<script src="../assets/js/bootstrap.min.js"></script> 
<script src="../assets/js/slick.min.js"></script> 
<script src="../assets/js/jquery.li-scroller.1.0.js"></script> 
<script src="../assets/js/jquery.newsTicker.min.js"></script> 
<script src="../assets/js/jquery.fancybox.pack.js"></script> 
<script src="../assets/js/custom.js"></script>
</body>
</html>