<html>
<?php include'common/head.php';?>
<body>
<?php include'common/nav.php';?>
  <section id="contentSection">
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-8">
        <div class="left_content">
          <div class="single_page">
            <ol class="breadcrumb">
              <li><a href="../index.php">Home</a></li>
              
            </ol>
            <h1>Hackers Who Hit Olympics 2018 Arw Still Alive and Kicking</h1>
            <div class="post_commentbox"> <a href="#"><i class="fa fa-user"></i>Wpfreeware</a> <span><i class="fa fa-calendar"></i>6:49 AM</span> <a href="#"><i class="fa fa-tags"></i>Technology</a> </div>
            <div class="single_page_content"> <img class="img-center" src="../images/1.jpg" alt="">
              <p>The group behind it is still alive, kicking and has now been found targeting biological and chemical threat prevention laboratories in Europe and Ukraine, and a few financial organisation in Russia.<br/><br/>

Earlier this year, an unknown group of notorious hackers targeted Winter Olympic Games 2018, held in South Korea, using a destructive malware that purposely planted sophisticated false flags to trick researchers into mis-attributing the campaign.<br/>
Unfortunately, the destructive malware was successful to some extent, at least for a next few days, as immediately after the attack various security researchers postmortem the Olympic Destroyer malware and started attributing the attack to different nation-state hacking groups from North Korea, Russia, and China.<br/>

Later researchers from Russian antivirus vendor Kaspersky Labs uncovered more details about the attack, including the evidence of false attribution artifacts, and concluded that the whole attack was a masterful operation in deception.<br/>
Now according to a new report published today by Kaspersky Labs, the same group of hackers, which is still unattributed, has been found targeting organisations in Russia, Ukraine, and several European countries in May and June 2018, specifically those organizations that respond to and protect against biological and chemical threats.<br/>
During their investigation, researchers found that the exploitation and deception tactics used by the newly discovered campaign share many similarities with the Olympic Destroyer attack.</p>
              <blockquote>"In May-June 2018 we discovered new spear-phishing documents that closely resembled weaponized documents used by Olympic Destroyer in the past," the researchers said. "They continue to use a non-binary executable infection vector and obfuscated scripts to evade detection."</blockquote>
              <p>Just like Olympic Destroyer, the new attack also targets users affiliated with specific organisations using spear-phishing emails that appear as coming from an acquaintance, with an attached document.<br/>

If the victims open the malicious document, it leverages macros to download and execute multiple PowerShell scripts in the background and install the final 3rd-stage payload to take remote control over the victims' system.<br/>

Researchers found that the technique used to obfuscate and decrypt the malicious code is same as used in the original Olympic Destroyer spear-phishing campaign.<br/>

The second-stage script disables Powershell script logging to avoid leaving traces and then downloads the final "Powershell Empire agent" payload, which allows fileless control of the compromised systems over an encrypted communication channel.</p>
              <ul>
                <li></li>
                <li></li>
                
              </ul>
              <h2></h2>
              <h3></h3>
              
              <button class="btn default-btn">Home</button>
              <button class="btn btn-red">Smartphone</button>
              <button class="btn btn-yellow">Computers</button>
              
             
            </div>
            <div class="social_link">
              <ul class="sociallink_nav">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
              </ul>
            </div>
            
          </div>
        </div>
      </div>
      <nav class="nav-slit"> <a class="prev" href="#"> <span class="icon-wrap"><i class="fa fa-angle-left"></i></span>
        <div>
          <h3>City Lights</h3>
          <img src="../images/post_img1.jpg" alt=""/> </div>
        </a> <a class="next" href="#"> <span class="icon-wrap"><i class="fa fa-angle-right"></i></span>
        <div>
          <h3>Street Hills</h3>
          <img src="../images/post_img1.jpg" alt=""/> </div>
        </a> </nav>
      <div class="col-lg-4 col-md-4 col-sm-4">
        <aside class="right_content">
         <?php include'common/popular.php';?>
          <div class="single_sidebar">
            <ul class="nav nav-tabs" role="tablist">
              <li role="presentation" class="active"><a href="#category" aria-controls="home" role="tab" data-toggle="tab">Category</a></li>
              <li role="presentation"><a href="#video" aria-controls="profile" role="tab" data-toggle="tab">Video</a></li>
            </ul>
            <div class="tab-content">
              <div role="tabpanel" class="tab-pane active" id="category">
                <ul>
                  <li class="cat-item"><a href="#">Sports</a></li>
                  <li class="cat-item"><a href="#">Fashion</a></li>
                  <li class="cat-item"><a href="#">Business</a></li>
                  <li class="cat-item"><a href="#">Technology</a></li>
                  <li class="cat-item"><a href="#">Games</a></li>
                  <li class="cat-item"><a href="#">Life &amp; Style</a></li>
                  <li class="cat-item"><a href="#">Photography</a></li>
                </ul>
              </div>
              <?php include'common/video.php';?>
              
            </div>
          </div>
          
          <div class="single_sidebar wow fadeInDown">
            <h2><span>Category Archive</span></h2>
            <select class="catgArchive">
              <option>Select Category</option>
              <option>Life styles</option>
              <option>Sports</option>
              <option>Technology</option>
              <option>Treads</option>
            </select>
          </div>
          <div class="single_sidebar wow fadeInDown">
            <h2><span>Links</span></h2>
           
          </div>
        </aside>
      </div>
    </div>
  </section>
<?php include'common/footer.php';?>
</div>
<script src="../assets/js/jquery.min.js"></script> 
<script src="../assets/js/wow.min.js"></script> 
<script src="../assets/js/bootstrap.min.js"></script> 
<script src="../assets/js/slick.min.js"></script> 
<script src="../assets/js/jquery.li-scroller.1.0.js"></script> 
<script src="../assets/js/jquery.newsTicker.min.js"></script> 
<script src="../assets/js/jquery.fancybox.pack.js"></script> 
<script src="../assets/js/custom.js"></script>
</body>
</html>