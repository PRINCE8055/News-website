<html>
<?php include'common/head.php';?>
<body>
<?php include'common/nav.php';?>
  <section id="contentSection">
  <section id="contentSection">
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-8">
        <div class="left_content">
          <div class="single_page">
            <ol class="breadcrumb">
              <li><a href="../index.php">Home</a></li>
              
            </ol>
            <h1>Yamaha R15 V3.0 MotoGP edition with custom livery is coming to India in August</h1>
            <div class="post_commentbox"> <a href="#"><i class="fa fa-user"></i>Technews</a> <span><i class="fa fa-calendar"></i></span> <a href="#"><i class="fa fa-tags"></i>Technology</a> </div>
            <div class="single_page_content"> <img class="img-center" src="../images/18.jpg" alt="">
    <p>


                  
                    
                  
                  

                    
                

                
                  
                    
                  
                
                
                  
                    
                  
                
                

                  
                    
                  
                  


    							
    								
    									
    									
    									
    								
    							

If you’ve been lusting after the Yamaha R15 for a while, you might want to wait just a little bit longer. A recent report reveals that the MotoGP edition of the R15 V3.0 is coming to India this August.<br/>

According to a report in Autocar India, except for cosmetic changes, the bike is identical to the R15 V3.0. The blue MotoGP edition features a “Movistar logo on the front and sides and an ENEOS logo on the belly pan,” says Autocar.<br/>

The standard edition of the bike is available at Rs 1.26 lakh and it’s expected that the MotoGP edition will be priced at a premium. The standard bike is available in Thunder Grey and Racing Blue colours. V3.0 of the bike was unveiled at Auto Expo 2018 in February this year.<br/>
he bike is powered by a 155 cc liquid-cooled that produces 19.3 bhp at 10,000 rpm and 15 Nm of torque at 8,500 rpm. The brakes include a large 282 mm disc on the front and a 220 mm one on the rear.</p>
             
            </div>
            <div class="social_link">
              <ul class="sociallink_nav">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
              </ul>
            </div>
            
          </div>
        </div>
      </div>
      <nav class="nav-slit"> <a class="prev" href="#"> <span class="icon-wrap"><i class="fa fa-angle-left"></i></span>
        <div>
          <h3>City Lights</h3>
          <img src="../images/post_img1.jpg" alt=""/> </div>
        </a> <a class="next" href="#"> <span class="icon-wrap"><i class="fa fa-angle-right"></i></span>
        <div>
          <h3>Street Hills</h3>
          <img src="../images/post_img1.jpg" alt=""/> </div>
        </a> </nav>
      <div class="col-lg-4 col-md-4 col-sm-4">
        <aside class="right_content">
          <?php include'common/popular.php';?>
          <div class="single_sidebar">
            <ul class="nav nav-tabs" role="tablist">
              <li role="presentation" class="active"><a href="#category" aria-controls="home" role="tab" data-toggle="tab">Category</a></li>
              <li role="presentation"><a href="#video" aria-controls="profile" role="tab" data-toggle="tab">Video</a></li>
            </ul>
            <div class="tab-content">
              <div role="tabpanel" class="tab-pane active" id="category">
                <ul>
                  <li class="cat-item"><a href="#">Sports</a></li>
                  <li class="cat-item"><a href="#">Fashion</a></li>
                  <li class="cat-item"><a href="#">Business</a></li>
                  <li class="cat-item"><a href="#">Technology</a></li>
                  <li class="cat-item"><a href="#">Games</a></li>
                  <li class="cat-item"><a href="#">Life &amp; Style</a></li>
                  <li class="cat-item"><a href="#">Photography</a></li>
                </ul>
              </div>
              <?php include'common/video.php';?>
            </div>
          </div>
         
          <div class="single_sidebar wow fadeInDown">
            <h2><span>Category Archive</span></h2>
            <select class="catgArchive">
              <option>Select Category</option>
              <option>Life styles</option>
              <option>Sports</option>
              <option>Technology</option>
              <option>Treads</option>
            </select>
          </div>
          <div class="single_sidebar wow fadeInDown">
            <h2><span>Links</span></h2>
            
          </div>
        </aside>
      </div>
    </div>
  </section>
  <?php include'common/footer.php';?>
</div>
<script src="../assets/js/jquery.min.js"></script> 
<script src="../assets/js/wow.min.js"></script> 
<script src="../assets/js/bootstrap.min.js"></script> 
<script src="../assets/js/slick.min.js"></script> 
<script src="../assets/js/jquery.li-scroller.1.0.js"></script> 
<script src="../assets/js/jquery.newsTicker.min.js"></script> 
<script src="../assets/js/jquery.fancybox.pack.js"></script> 
<script src="../assets/js/custom.js"></script>
</body>
</html>