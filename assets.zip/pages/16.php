<html>
<?php include'common/head.php';?>
<body>
<?php include'common/nav.php';?>
  <section id="contentSection">
  <section id="contentSection">
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-8">
        <div class="left_content">
          <div class="single_page">
            <ol class="breadcrumb">
              <li><a href="../index.php">Home</a></li>
              <li><a href="#">Technology</a></li>
              <li class="active">Mobile</li>
            </ol>
            <h1>The Asus ROG Phone might make its way to India by September this year</h1>
            <div class="post_commentbox"> <a href="#"><i class="fa fa-user"></i>Hackingnews.com</a> <span><i class="fa fa-calendar"></i></span> <a href="#"><i class="fa fa-tags"></i>Technology</a> </div>
            <div class="single_page_content"> <img class="img-center" src="../images/16.jpg" alt="">
             <p>The Asus ROG Phone was announced at Computex 2018 and it is one of the few devices that panders to a niche, hard-core audience interested in gaming on a smartphone. Before the ROG Phone, it was the Razer Phone and the Xiaomi BlackShark.<br/> While the latter two have not made it to the Indian market,<br/> it would seem that the ROG Phone just might.
			 
                    
                

                
                  
                    
                  
                
                
                  
                    
                  
                
                

                  
                    
                  
                  


    							
    								
    									
    									
    									
    								
    							

The Asus ROG Phone was announced at Computex 2018 and it is one of the few devices that panders to a niche, hard-core audience interested in gaming on a smartphone. Before the ROG Phone, it was the Razer Phone and the Xiaomi BlackShark. While the latter two have not made it to the Indian market, it would seem that the ROG Phone just might.
Asus ROG Phone.

Asus ROG Phone.

If it does come to India, the Asus ROG Phone will be the very first gaming-centric smartphone introduced in the country. As per a report by Gizmochina, the ROG Phone is expected to arrive in India around September, after which the phone will also be included in the European markets.

However, it is best to take this information as a rumour because there has been no official confirmation from the company itself.<br/>

In a country like India, where esports is still in its developmental stage, introducing the ROG Phone might give the necessary push<br/> required kickstart India's mobile esports revolution. But that's maybe just wishful thinking.

To recall, the phone is powered by a special Snapdragon 845 SoC which has custom Kryo cores clocked to a whopping 2.9 GHz to provide "seamless" gaming.<br/> The RAM on the phone happens to be 8 GB and there also is a 512 GB of internal storage variant.

The ROG Phone has a 6-inch 2,160 x 1,080 AMOLED display and powering the phone is a 4,000 mAh battery, which supports ASUS HyperCharge, preventing the device from heating during charging. The phone also makes use of Quick Charge 4.0, which reportedly charges the phone up from 0-66 percent in 30 minutes.</p>
             
            </div>
            <div class="social_link">
              <ul class="sociallink_nav">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
              </ul>
            </div>
            
          </div>
        </div>
      </div>
      <nav class="nav-slit"> <a class="prev" href="#"> <span class="icon-wrap"><i class="fa fa-angle-left"></i></span>
        <div>
          <h3>City Lights</h3>
          <img src="../images/post_img1.jpg" alt=""/> </div>
        </a> <a class="next" href="#"> <span class="icon-wrap"><i class="fa fa-angle-right"></i></span>
        <div>
          <h3>Street Hills</h3>
          <img src="../images/post_img1.jpg" alt=""/> </div>
        </a> </nav>
      <div class="col-lg-4 col-md-4 col-sm-4">
        <aside class="right_content">
          <?php include'common/popular.php';?>
          <div class="single_sidebar">
            <ul class="nav nav-tabs" role="tablist">
              <li role="presentation" class="active"><a href="#category" aria-controls="home" role="tab" data-toggle="tab">Category</a></li>
              <li role="presentation"><a href="#video" aria-controls="profile" role="tab" data-toggle="tab">Video</a></li>
            </ul>
            <div class="tab-content">
              <div role="tabpanel" class="tab-pane active" id="category">
                <ul>
                  <li class="cat-item"><a href="#">Sports</a></li>
                  <li class="cat-item"><a href="#">Fashion</a></li>
                  <li class="cat-item"><a href="#">Business</a></li>
                  <li class="cat-item"><a href="#">Technology</a></li>
                  <li class="cat-item"><a href="#">Games</a></li>
                  <li class="cat-item"><a href="#">Life &amp; Style</a></li>
                  <li class="cat-item"><a href="#">Photography</a></li>
                </ul>
              </div>
              <?php include'common/video.php';?>
            </div>
          </div>
         
          <div class="single_sidebar wow fadeInDown">
            <h2><span>Category Archive</span></h2>
            <select class="catgArchive">
              <option>Select Category</option>
              <option>Life styles</option>
              <option>Sports</option>
              <option>Technology</option>
              <option>Treads</option>
            </select>
          </div>
          <div class="single_sidebar wow fadeInDown">
            <h2><span>Links</span></h2>
            
          </div>
        </aside>
      </div>
    </div>
  </section>
  <?php include'common/footer.php';?>
</div>
<script src="../assets/js/jquery.min.js"></script> 
<script src="../assets/js/wow.min.js"></script> 
<script src="../assets/js/bootstrap.min.js"></script> 
<script src="../assets/js/slick.min.js"></script> 
<script src="../assets/js/jquery.li-scroller.1.0.js"></script> 
<script src="../assets/js/jquery.newsTicker.min.js"></script> 
<script src="../assets/js/jquery.fancybox.pack.js"></script> 
<script src="../assets/js/custom.js"></script>
</body>
</html>