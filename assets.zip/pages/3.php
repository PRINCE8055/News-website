<html>
<?php include'common/head.php';?>
<body>
<?php include'common/nav.php';?>
  <section id="contentSection">
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-8">
        <div class="left_content">
          <div class="single_page">
            <ol class="breadcrumb">
              <li><a href="../index.phpl">Home</a></li>
              
            </ol>
            <h1>Were real dinosaurs as bulletproof as the one in Jurassic World: Fallen Kingdom? </h1>
            <div class="post_commentbox"> <a href="#"><i class="fa fa-user"></i>Hackingnews.com</a> <span><i class="fa fa-calendar"></i>6:49 AM</span> <a href="#"><i class="fa fa-tags"></i>Technology</a> </div>
            <div class="single_page_content"> <img class="img-center" src="../images/3.jpg" alt="">
              <p>At one point in the new film Jurassic World: Fallen Kingdom, Velociraptor trainer Owen Grady (Chris Pratt) fires multiple rifle shots into the “Indoraptor,” a new dinosaur hybrid constructed from DNA taken from Tyrannosaurus rex samples, Velociraptors, and god knows what else. The dinosaur cowers for a couple seconds, then charges at its prey, seemingly undamaged. Like the Indominus rex in the first Jurassic World, the franchise’s latest human-made dino seems to be immune to gunfire.

Obviously, there’s a fair bit of scientific fudging going on in the Jurassic Park series, given that the entire series’ premise is based on an incorrect idea of how long DNA can be preserved. But that image of dinosaurs shrugging off gunfire for dramatic purposes pops up fairly often in action movies where dinosaurs and modern weaponry somehow co-exist. Is there any basis in fact there? Could dinosaurs actually have been bulletproof?

<blocq“I guess that depends on what kinds of bullets you’re shooting at them,” says Jordan Mallon, a paleobiologist and dinosaur expert at the Canadian Museum of Nature. “If you shoot a little .22 at a big moose, you’re probably just going to make it angry. But if you shoot it with a rifle round, then you’re going to kill it. I suspect the same would be true of dinosaurs.<blockquote><h3>"“I guess that depends on what kinds of bullets you’re shooting at them”"</h3></blockquote>

But just as the bullet size matters, so does the dinosaur. One particular dino could have withstood gunfire more effectively than others: a tank-like creature called the Ankylosaurus. These massive dinosaurs sported incredibly strong armor — bony plates that covered their backs, skulls, and even their eyes and cheeks. “Their skulls were just one solid mass of bone,” Mallon tells The Verge. “They would have been difficult to take out.” The bony plates, which were embedded in their skin, had collagen fibers that were crisscrossed like fibers in a Kevlar bulletproof vest. That allowed the armor to withstand the bites of a T. rex, which had fangs as long as bananas, if you include the roots.

However strong, that armor couldn’t have stopped bullets, says Philip Senter, a paleontologist at Fayetteville State University. “It’s still bone; it’s brittle,” he tells The Verge. “A bullet will shatter it.” But Mallon isn’t so sure. Though it’s an exaggeration to call the armor “bulletproof,” an Ankylosaurus could have likely survived a shot from a small pistol, he says. John “Jack” Horner, a paleontologist at Montana State University, agrees. “There’s no doubt that the armor of an Ankylosaurus would likely stop small gun fire,” Horner tells The Verge. A shot from a rifle or other big Hollywood weapons are another story, he says.

Horner, the science advisor on all the Jurassic Park and Jurassic World movies, says he actually pushed back against the idea of making dinosaurs bulletproof in the franchise. Initially, the makers of Jurassic World wanted to know if the Indominus rex could be bulletproof, according to NBC News. But Horner told them that even an engineered creature shouldn’t have fictional characteristics — it had to borrow attributes from existing animals whose DNA is embedded in the new dinosaur. And no animals alive today are bulletproof. “They wanted to give it superpowers,” Horner tells The Verge</p>
              <h2></h2>
              <h3></h3>
              
              <button class="btn default-btn">Home</button>
              <button class="btn btn-red">Smartphone</button>
              <button class="btn btn-yellow">Computers</button>
              
             
            </div>
            <div class="social_link">
              <ul class="sociallink_nav">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
              </ul>
            </div>
           
          </div>
        </div>
      </div>
      <nav class="nav-slit"> <a class="prev" href="#"> <span class="icon-wrap"><i class="fa fa-angle-left"></i></span>
        <div>
          <h3>City Lights</h3>
          <img src="../images/post_img1.jpg" alt=""/> </div>
        </a> <a class="next" href="#"> <span class="icon-wrap"><i class="fa fa-angle-right"></i></span>
        <div>
          <h3>Street Hills</h3>
          <img src="../images/post_img1.jpg" alt=""/> </div>
        </a> </nav>
      <div class="col-lg-4 col-md-4 col-sm-4">
        <aside class="right_content">
          <?php include'common/video.php';?>
          <div class="single_sidebar">
            <ul class="nav nav-tabs" role="tablist">
              <li role="presentation" class="active"><a href="#category" aria-controls="home" role="tab" data-toggle="tab">Category</a></li>
              <li role="presentation"><a href="#video" aria-controls="profile" role="tab" data-toggle="tab">Video</a></li>
            </ul>
            <div class="tab-content">
              <div role="tabpanel" class="tab-pane active" id="category">
                <ul>
                  <li class="cat-item"><a href="#">Sports</a></li>
                  <li class="cat-item"><a href="#">Fashion</a></li>
                  <li class="cat-item"><a href="#">Business</a></li>
                  <li class="cat-item"><a href="#">Technology</a></li>
                  <li class="cat-item"><a href="#">Games</a></li>
                  <li class="cat-item"><a href="#">Life &amp; Style</a></li>
                  <li class="cat-item"><a href="#">Photography</a></li>
                </ul>
              </div>
             <?php include'common/video.php';?>
            </div>
          </div>
          
          <div class="single_sidebar wow fadeInDown">
            <h2><span>Category Archive</span></h2>
            <select class="catgArchive">
              <option>Select Category</option>
              <option>Life styles</option>
              <option>Sports</option>
              <option>Technology</option>
              <option>Treads</option>
            </select>
          </div>
          <div class="single_sidebar wow fadeInDown">
            <h2><span>Links</span></h2>
            
          </div>
        </aside>
      </div>
    </div>
  </section>
  <?php include'common/footer.php';?>
</div>
<script src="../assets/js/jquery.min.js"></script> 
<script src="../assets/js/wow.min.js"></script> 
<script src="../assets/js/bootstrap.min.js"></script> 
<script src="../assets/js/slick.min.js"></script> 
<script src="../assets/js/jquery.li-scroller.1.0.js"></script> 
<script src="../assets/js/jquery.newsTicker.min.js"></script> 
<script src="../assets/js/jquery.fancybox.pack.js"></script> 
<script src="../assets/js/custom.js"></script>
</body>
</html>