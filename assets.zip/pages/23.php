<html>
<?php include'common/head.php';?>
<body>
<?php include'common/nav.php';?>
  <section id="contentSection">
  <section id="contentSection">
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-8">
        <div class="left_content">
          <div class="single_page">
            <ol class="breadcrumb">
              <li><a href="../index.php">Home</a></li>
              
            </ol>
            <h1>Samsung is working on a bezel-less smartphone with two screens, according to a patent which was filed in 2016, and has just been granted by the United States Patent & Trademark Office (USPTO) (via MobielKopen). </h1>
            <div class="post_commentbox"> <a href="#"><i class="fa fa-user"></i>Technews</a> <span><i class="fa fa-calendar"></i></span> <a href="#"><i class="fa fa-tags"></i>Technology</a> </div>
            <div class="single_page_content"> <img class="img-center" src="../images/22.jpg" alt="">
    <p>Samsung is working on a bezel-less smartphone with two screens, according to a patent which was filed in 2016, and has just been granted by the United States Patent & Trademark Office (USPTO) (via MobielKopen). A recently filed patent provides a snapshot of what might be on the horizon for the next-generation Galaxy smartphone from the South Korean major.<br/>

The patent application shows a smartphone with a bezel-less display, and a secondary display on the back. The concept of having a secondary display on the rear is nothing new. We’ve already seen the implementation of a secondary screen on the back with the YotaPhone and Meizu Pro 7. A display on the rear of the phone is an interesting idea, <br/>though its execution so far has been a hit-and-miss affair.
Samsung is expected to launch the Galaxy Note 9 later this year, but if you’re holding out for a Galaxy-branded dual-screen smartphone, don’t get too excited. As usual, a patent is not a proof that a certain product enters production, but it does provide an early glimpse of the design language the company might be interested in. In this case, even if a smartphone with a secondary display is coming, it certainly wouldn’t arrive until next year.

Of late, a lot of smartphones including the likes of Oppo and Vivo are trying to hard to experiment with new designs. For instance, Oppo recently unveiled the Find X that features an edge-to-edge display with a screen-to-body ratio of 93.8 per cent on the front. The smartphone avoids the controversial design language with a motorised camera array that raises out of the body, revealing a dual-camera setup on the back and a single snapper over the screen. Oppo Find X is said to launch in India on July 12 at a premium price.</p>
             
            </div>
            <div class="social_link">
              <ul class="sociallink_nav">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
              </ul>
            </div>
            
          </div>
        </div>
      </div>
      <nav class="nav-slit"> <a class="prev" href="#"> <span class="icon-wrap"><i class="fa fa-angle-left"></i></span>
        <div>
          <h3>City Lights</h3>
          <img src="../images/post_img1.jpg" alt=""/> </div>
        </a> <a class="next" href="#"> <span class="icon-wrap"><i class="fa fa-angle-right"></i></span>
        <div>
          <h3>Street Hills</h3>
          <img src="../images/post_img1.jpg" alt=""/> </div>
        </a> </nav>
      <div class="col-lg-4 col-md-4 col-sm-4">
        <aside class="right_content">
          <?php include'common/popular.php';?>
          <div class="single_sidebar">
            <ul class="nav nav-tabs" role="tablist">
              <li role="presentation" class="active"><a href="#category" aria-controls="home" role="tab" data-toggle="tab">Category</a></li>
              <li role="presentation"><a href="#video" aria-controls="profile" role="tab" data-toggle="tab">Video</a></li>
            </ul>
            <div class="tab-content">
              <div role="tabpanel" class="tab-pane active" id="category">
                <ul>
                  <li class="cat-item"><a href="#">Sports</a></li>
                  <li class="cat-item"><a href="#">Fashion</a></li>
                  <li class="cat-item"><a href="#">Business</a></li>
                  <li class="cat-item"><a href="#">Technology</a></li>
                  <li class="cat-item"><a href="#">Games</a></li>
                  <li class="cat-item"><a href="#">Life &amp; Style</a></li>
                  <li class="cat-item"><a href="#">Photography</a></li>
                </ul>
              </div>
              <?php include'common/video.php';?>
            </div>
          </div>
         
          <div class="single_sidebar wow fadeInDown">
            <h2><span>Category Archive</span></h2>
            <select class="catgArchive">
              <option>Select Category</option>
              <option>Life styles</option>
              <option>Sports</option>
              <option>Technology</option>
              <option>Treads</option>
            </select>
          </div>
          <div class="single_sidebar wow fadeInDown">
            <h2><span>Links</span></h2>
            
          </div>
        </aside>
      </div>
    </div>
  </section>
  <?php include'common/footer.php';?>
</div>
<script src="../assets/js/jquery.min.js"></script> 
<script src="../assets/js/wow.min.js"></script> 
<script src="../assets/js/bootstrap.min.js"></script> 
<script src="../assets/js/slick.min.js"></script> 
<script src="../assets/js/jquery.li-scroller.1.0.js"></script> 
<script src="../assets/js/jquery.newsTicker.min.js"></script> 
<script src="../assets/js/jquery.fancybox.pack.js"></script> 
<script src="../assets/js/custom.js"></script>
</body>
</html>