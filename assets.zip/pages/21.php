<html>
<?php include'common/head.php';?>
<body>
<?php include'common/nav.php';?>
  <section id="contentSection">
  <section id="contentSection">
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-8">
        <div class="left_content">
          <div class="single_page">
            <ol class="breadcrumb">
              <li><a href="../index.php">Home</a></li>
              
            </ol>
            <h1>How to pick the most genuine pair of leather shoes</h1>
            <div class="post_commentbox"> <a href="#"><i class="fa fa-user"></i>Lifestyle</a> <span><i class="fa fa-calendar"></i></span> <a href="#"><i class="fa fa-tags"></i>Technology</a> </div>
            <div class="single_page_content"> <img class="img-center" src="../images/21.jpg" alt="">
    <p>Shoes are an important part of one's wardrobe and they enhance one's look. <br/>Experts suggest a few tips while picking up leather shoes. Comfort should be kept in mind along with the fact that leather shoes cost more also how the sole indicates quality.<br/>
	Shoes are a crucial part of a wardrobe especially the leather ones. A right pair can accentuate your look whereas a wrong choice can break your entire look no matter how great the outfit so opt for the one that suits your personality, comfort. Ritesh Srivastava, CEO at Elitify.com and Jyoti Narula, Director at JOE SHU share a few tips to keep in mind while buying a pair of genuine leather shoes.<br/>

* Shoe surface: The tactile feel of the shoe surface plays a significant role in deciding the authenticity of leather by the buyer. A pair of genuine leather shoes will usually have a sanded and refinished surface. It would not have a plastic feel or artificial finish that is common with faux leather.<br/>

* The insole – One should examine the detailing of the inner lining of the shoes which is another important indicator of quality. Genuine leather shoes will have an extra padded insole that works as a cushion between the feet and the shoes giving comfort and ensuring a sturdy grip.<br/>

* Price factor – As a general rule genuine leather costs more. It demands a relatively higher cost for the kind of durability, aesthetic appeal and fine detailing it brings to the footwear.<br/>

* Finishing and stitching – Aesthetics play a very important role while choosing a pair of shoes. An elegant silhouette is what adds to instant appeal along with its perfect coloration. The stitching should also be neat and smooth, thereby depicting attention to detail. More so in handcrafted or hand painted shoes.<br/>

* Comfort – A fine craftsman of shoes will always focus on comfort along with the styling. There is nothing worse than a shoe that bites.<br/>

* Rich fragrance of leather – A crucial point in identifying a real leather shoe is its smell. A shoe made of genuine leather will always carry a rich fragrance which is a natural odour. Authentic leather will never smell of chemicals or plastic.<br/>

* The sole – Sole is an important indicator of quality. The better the sole and the lining the more comfort and grip it offers. The shoes should always be light in weight. An extra layer of the sole between the shoe body and the feet will give freedom to the wearer for long hours.</p>
             
            </div>
            <div class="social_link">
              <ul class="sociallink_nav">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
              </ul>
            </div>
            
          </div>
        </div>
      </div>
      <nav class="nav-slit"> <a class="prev" href="#"> <span class="icon-wrap"><i class="fa fa-angle-left"></i></span>
        <div>
          <h3>City Lights</h3>
          <img src="../images/post_img1.jpg" alt=""/> </div>
        </a> <a class="next" href="#"> <span class="icon-wrap"><i class="fa fa-angle-right"></i></span>
        <div>
          <h3>Street Hills</h3>
          <img src="../images/post_img1.jpg" alt=""/> </div>
        </a> </nav>
      <div class="col-lg-4 col-md-4 col-sm-4">
        <aside class="right_content">
          <?php include'common/popular.php';?>
          <div class="single_sidebar">
            <ul class="nav nav-tabs" role="tablist">
              <li role="presentation" class="active"><a href="#category" aria-controls="home" role="tab" data-toggle="tab">Category</a></li>
              <li role="presentation"><a href="#video" aria-controls="profile" role="tab" data-toggle="tab">Video</a></li>
            </ul>
            <div class="tab-content">
              <div role="tabpanel" class="tab-pane active" id="category">
                <ul>
                  <li class="cat-item"><a href="#">Sports</a></li>
                  <li class="cat-item"><a href="#">Fashion</a></li>
                  <li class="cat-item"><a href="#">Business</a></li>
                  <li class="cat-item"><a href="#">Technology</a></li>
                  <li class="cat-item"><a href="#">Games</a></li>
                  <li class="cat-item"><a href="#">Life &amp; Style</a></li>
                  <li class="cat-item"><a href="#">Photography</a></li>
                </ul>
              </div>
              <?php include'common/video.php';?>
            </div>
          </div>
         
          <div class="single_sidebar wow fadeInDown">
            <h2><span>Category Archive</span></h2>
            <select class="catgArchive">
              <option>Select Category</option>
              <option>Life styles</option>
              <option>Sports</option>
              <option>Technology</option>
              <option>Treads</option>
            </select>
          </div>
          <div class="single_sidebar wow fadeInDown">
            <h2><span>Links</span></h2>
            
          </div>
        </aside>
      </div>
    </div>
  </section>
  <?php include'common/footer.php';?>
</div>
<script src="../assets/js/jquery.min.js"></script> 
<script src="../assets/js/wow.min.js"></script> 
<script src="../assets/js/bootstrap.min.js"></script> 
<script src="../assets/js/slick.min.js"></script> 
<script src="../assets/js/jquery.li-scroller.1.0.js"></script> 
<script src="../assets/js/jquery.newsTicker.min.js"></script> 
<script src="../assets/js/jquery.fancybox.pack.js"></script> 
<script src="../assets/js/custom.js"></script>
</body>
</html>