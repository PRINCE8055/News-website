<?php
$con= new mysqli('localhost','sabsacad_usersr','Jackamp00.','sabsacad_feedback')or die("Could not connect to mysql".mysqli_error($con));

?>