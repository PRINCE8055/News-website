<html>
<?php include'common/head.php';?>
<body>
<?php include'common/nav.php';?>
  <section id="contentSection">
  <section id="contentSection">
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-8">
        <div class="left_content">
          <div class="single_page">
            <ol class="breadcrumb">
              <li><a href="../index.php">Home</a></li>
              <li><a href="#">Technology</a></li>
              <li class="active">Mobile</li>
            </ol>
            <h1>SUMMER SOLSTICE:longest day of the year</h1>
            <div class="post_commentbox"> <a href="#"><i class="fa fa-user"></i>Hackingnews.com</a> <span><i class="fa fa-calendar"></i></span> <a href="#"><i class="fa fa-tags"></i>Technology</a> </div>
            <div class="single_page_content"> <img class="img-center" src="../images/12.jpg" alt="">
             <P> summer solistice or also called midsummer, occurs when a planet's rotational axis, or geographical pole on either its Northern or its Southern Hemisphere, is most greatly inclined toward the star that it orbits. On the summer solstice, Earth's maximum axial tilt toward the Sun is 23.44°. (Likewise, the Sun's declination from the celestial equator is 23.44°.) This happens twice each year (once in each hemisphere), when the Sun reaches its highest position in the sky as seen from the North or South Pole.

The summer solstice occurs during the hemisphere's summer.[2] This is the June solstice in the Northern Hemisphere and the December solstice in the Southern Hemisphere. Depending on the shift of the calendar, the summer solstice occurs some time between June 20 and June 22 in the Northern Hemisphere[3][4] and between December 20 and December 23 each year in the Southern Hemisphere.[5] The same dates in the opposite hemisphere are referred to as the winter solstice.

As seen from a geographic pole, the Sun reaches its highest altitude of the year on the summer solstice. The colloquial term "midsummer" refers to the day on which the solstice occurs. The summer solstice day has the longest period of daylight, except in the polar regions, where daytime remains continuous for 24 hours every day during a period ranging from a few days to six months around the summer solstice.
 Although the summer solstice is the longest day of the year for that hemisphere, the dates of earliest sunrise and latest sunset vary by a few days.[6] This is because the earth orbits the sun in an ellipse, and its orbital speed varies slightly during the year.[7] See the Equation of time for details. Although the sun appears at its highest altitude from the viewpoint of an observer in outer space or a terrestrial observer outside tropical latitudes, the highest altitude occurs on a different day for certain locations in the tropics, specifically those where the sun is directly overhead (maximum 90 degrees elevation) at the subsolar point. This day occurs twice each year for all locations between the Tropic of Cancer and Tropic of Capricorn because the overhead sun appears to cross a given latitude once before the day of the solstice and once afterward. For example, Lahaina Noon occurs in May and July in Hawaii. See solstice article. For all observers, the apparent position of the noon sun is at its most northerly point on the June solstice and most southerly on the December solstice.
 <blockquote> full moon</blockquote> <br>2016 was the first time in nearly 70 years that a full moon and the Northern Hemisphere's summer solstice occurred on the same day.[8] The 2016 summer solstice's full moon rose just as the sun set.[</p>
              <button class="btn default-btn">Home</button>
              <button class="btn btn-red">Smartphone</button>
              <button class="btn btn-yellow">Computers</button>
              
             
            </div>
            <div class="social_link">
              <ul class="sociallink_nav">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
              </ul>
            </div>
            
          </div>
        </div>
      </div>
      <nav class="nav-slit"> <a class="prev" href="#"> <span class="icon-wrap"><i class="fa fa-angle-left"></i></span>
        <div>
          <h3>City Lights</h3>
          <img src="../images/post_img1.jpg" alt=""/> </div>
        </a> <a class="next" href="#"> <span class="icon-wrap"><i class="fa fa-angle-right"></i></span>
        <div>
          <h3>Street Hills</h3>
          <img src="../images/post_img1.jpg" alt=""/> </div>
        </a> </nav>
      <div class="col-lg-4 col-md-4 col-sm-4">
        <aside class="right_content">
          <?php include'common/popular.php';?>
          <div class="single_sidebar">
            <ul class="nav nav-tabs" role="tablist">
              <li role="presentation" class="active"><a href="#category" aria-controls="home" role="tab" data-toggle="tab">Category</a></li>
              <li role="presentation"><a href="#video" aria-controls="profile" role="tab" data-toggle="tab">Video</a></li>
            </ul>
            <div class="tab-content">
              <div role="tabpanel" class="tab-pane active" id="category">
                <ul>
                  <li class="cat-item"><a href="#">Sports</a></li>
                  <li class="cat-item"><a href="#">Fashion</a></li>
                  <li class="cat-item"><a href="#">Business</a></li>
                  <li class="cat-item"><a href="#">Technology</a></li>
                  <li class="cat-item"><a href="#">Games</a></li>
                  <li class="cat-item"><a href="#">Life &amp; Style</a></li>
                  <li class="cat-item"><a href="#">Photography</a></li>
                </ul>
              </div>
              <?php include'common/video.php';?>
            </div>
          </div>
         
          <div class="single_sidebar wow fadeInDown">
            <h2><span>Category Archive</span></h2>
            <select class="catgArchive">
              <option>Select Category</option>
              <option>Life styles</option>
              <option>Sports</option>
              <option>Technology</option>
              <option>Treads</option>
            </select>
          </div>
          <div class="single_sidebar wow fadeInDown">
            <h2><span>Links</span></h2>
            
          </div>
        </aside>
      </div>
    </div>
  </section>
  <?php include'common/footer.php';?>
</div>
<script src="../assets/js/jquery.min.js"></script> 
<script src="../assets/js/wow.min.js"></script> 
<script src="../assets/js/bootstrap.min.js"></script> 
<script src="../assets/js/slick.min.js"></script> 
<script src="../assets/js/jquery.li-scroller.1.0.js"></script> 
<script src="../assets/js/jquery.newsTicker.min.js"></script> 
<script src="../assets/js/jquery.fancybox.pack.js"></script> 
<script src="../assets/js/custom.js"></script>
</body>
</html>