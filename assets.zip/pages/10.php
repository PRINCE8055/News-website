<html>
<?php include'common/head.php';?>
<body>
<?php include'common/nav.php';?>
  <section id="contentSection">
  <section id="contentSection">
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-8">
        <div class="left_content">
          <div class="single_page">
            <ol class="breadcrumb">
              <li><a href="../index.php">Home</a></li>
              <li><a href="#">Technology</a></li>
              <li class="active">Mobile</li>
            </ol>
            <h1>now robots can ‘read’ your mind but you can't? </h1>
            <div class="post_commentbox"> <a href="#"><i class="fa fa-user"></i>Hackingnews.com</a> <span><i class="fa fa-calendar"></i>6:49 AM</span> <a href="#"><i class="fa fa-tags"></i>Technology</a> </div>
            <div class="single_page_content"> <img class="img-center" src="../images/11.jpg" alt="">
             
 sci-fi dream might not be so far off. With a new robot control system, a human can stop a bot from making a mistake and get the machine back on track using brain waves and simple hand gestures. People who oversee robots in factories, homes or hospitals could use this setup, to be presented at the Robotics: Science and Systems conference on June 28, to ensure bots operate safely and efficiently.

Electrodes worn on the head and forearm allow a person to control the robot. The head-worn electrodes detect electrical signals called error-related potentials — which people’s brains unconsciously generate when they see someone goof up — and send an alert to the robot. When the robot receives an error signal, it stops what it is doing. The person can then make hand gestures — detected by arm-worn electrodes that monitor electrical muscle signals — to show the bot what it should do instead.

MIT roboticist Daniela Rus and colleagues tested the system with seven volunteers. Each user supervised a robot that moved a drill toward one of three possible targets, each marked by an LED bulb, on a mock airplane fuselage. Whenever the robot zeroed in on the wrong target, the user’s mental error-alert halted the bot. And when the user flicked his or her wrist left or right to redirect the robot, the machine moved toward the proper target. In more than 1,000 trials, the robot initially aimed for the correct target about 70 percent of the time, and with human intervention chose the right target more than 97 percent of the time.

The team plans to build a system version that recognizes a wider variety of user movements. That way, “you can gesture how the robot should move, and your motion can be more fluidly interpreted,” says study coauthor Joseph DelPreto, also a roboticist at MIT.

Issuing commands via brain and muscle activity could work especially well in noisy or poorly lit places like factories or outdoors. In such areas, other hands-off means of directing robots, such as visual cues or verbal instructions, may not work as well, says Alexandre Barachant, a brain-computer interface researcher at CTRL-Labs in New York City. This technique could also be used to direct robots that assist people who can’t speak or can hardly move, such as patients with amyotrophic lateral sclerosis, or ALS (SN: 11/16/13, p. 22).
</p>
              <button class="btn default-btn">Home</button>
              <button class="btn btn-red">Smartphone</button>
              <button class="btn btn-yellow">Computers</button>
              
             
            </div>
            <div class="social_link">
              <ul class="sociallink_nav">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
              </ul>
            </div>
            
          </div>
        </div>
      </div>
      <nav class="nav-slit"> <a class="prev" href="#"> <span class="icon-wrap"><i class="fa fa-angle-left"></i></span>
        <div>
          <h3>City Lights</h3>
          <img src="../images/post_img1.jpg" alt=""/> </div>
        </a> <a class="next" href="#"> <span class="icon-wrap"><i class="fa fa-angle-right"></i></span>
        <div>
          <h3>Street Hills</h3>
          <img src="../images/post_img1.jpg" alt=""/> </div>
        </a> </nav>
      <div class="col-lg-4 col-md-4 col-sm-4">
        <aside class="right_content">
          <?php include'common/popular.php';?>
          <div class="single_sidebar">
            <ul class="nav nav-tabs" role="tablist">
              <li role="presentation" class="active"><a href="#category" aria-controls="home" role="tab" data-toggle="tab">Category</a></li>
              <li role="presentation"><a href="#video" aria-controls="profile" role="tab" data-toggle="tab">Video</a></li>
            </ul>
            <div class="tab-content">
              <div role="tabpanel" class="tab-pane active" id="category">
                <ul>
                  <li class="cat-item"><a href="#">Sports</a></li>
                  <li class="cat-item"><a href="#">Fashion</a></li>
                  <li class="cat-item"><a href="#">Business</a></li>
                  <li class="cat-item"><a href="#">Technology</a></li>
                  <li class="cat-item"><a href="#">Games</a></li>
                  <li class="cat-item"><a href="#">Life &amp; Style</a></li>
                  <li class="cat-item"><a href="#">Photography</a></li>
                </ul>
              </div>
              <?php include'common/video.php';?>
            </div>
          </div>
         
          <div class="single_sidebar wow fadeInDown">
            <h2><span>Category Archive</span></h2>
            <select class="catgArchive">
              <option>Select Category</option>
              <option>Life styles</option>
              <option>Sports</option>
              <option>Technology</option>
              <option>Treads</option>
            </select>
          </div>
          <div class="single_sidebar wow fadeInDown">
            <h2><span>Links</span></h2>
            
          </div>
        </aside>
      </div>
    </div>
  </section>
  <?php include'common/footer.php';?>
</div>
<script src="../assets/js/jquery.min.js"></script> 
<script src="../assets/js/wow.min.js"></script> 
<script src="../assets/js/bootstrap.min.js"></script> 
<script src="../assets/js/slick.min.js"></script> 
<script src="../assets/js/jquery.li-scroller.1.0.js"></script> 
<script src="../assets/js/jquery.newsTicker.min.js"></script> 
<script src="../assets/js/jquery.fancybox.pack.js"></script> 
<script src="../assets/js/custom.js"></script>
</body>
</html>