<html>
<?php include'common/head.php';?>
<body>
<?php include'common/nav.php';?>
  <section id="contentSection">
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-8">
        <div class="left_content">
          <div class="single_page">
            <ol class="breadcrumb">
              <li><a href="../index.php">Home</a></li>
             
            </ol>
            <h1>Ex cia employee charged with leaking 'Vault 7' hacking tools to Wikileaks</h1>
            <div class="post_commentbox"> <a href="#"><i class="fa fa-user"></i>Hackingnews.com</a> <span><i class="fa fa-calendar"></i>6:49 AM</span> <a href="#"><i class="fa fa-tags"></i>Technology</a> </div>
            <div class="single_page_content"> <img class="img-center" src="../images/2.jpg" alt="">
              <p>A 29-year-old former CIA computer programmer who was charged with possession of child pornography last year has now been charged with masterminding the largest leak of classified information in the agency's history.

Joshua Adam Schulte, who once created malware for both the CIA and NSA to break into adversaries computers, was indicted Monday by the Department of Justice on 13 charges of allegedly stealing and transmitting thousands of classified CIA documents, software projects, and hacking utilities.

Schulte has also been suspected of leaking the stolen archive of documents to anti-secrecy organization WikiLeaks, who then began publishing the classified information in March 2017 in a series of leaks under the name "Vault 7."<br/>
<br/>
It is yet unconfirmed whether Schulte leaked documents to WikiLeaks and if yes, then when, but he had already been a suspect since January 2017 of stealing classified national defense information from the CIA in 2016.

According to the indictment, after stealing the classified documents, Schulte tried to cover his tracks by altering a computer operated by the US Intelligence Agency to grant him unauthorized access to the system in March and June of 2016 and then deleting records of his activities and denying others access to the system.

In March 2017, during when WikiLeaks began releasing some of the CIA's hacking tools, the FBI agents searched Schulte's apartment as part of an ongoing investigation to find the mastermind behind the Vault 7 leaks.</p>
              <blockquote>"However, instead, the FBI found images of children being molested by adults on a server he created in 2009 while he was a student at the University of Texas. The maximum penalty for this is 130 years in prison.

Schulte was arrested in August 2017 with possession of child pornography, but prosecutors had been unable to bring charges of "disclosure of the classified information" against him until now.

However, now the revised indictment includes 13 counts of charges related to the theft and disclosure of the classified information to WikiLeaks and his possession of child pornography."</blockquote>
              <p>Schulte has pleaded not guilty to the child pornography charges and has repeatedly denied any of his involvement in the Vault 7 case.

The Vault 7 release was one of the most significant leaks in the CIA's history, exposing secret cyber weapons and spying techniques that the United States used to monitor or break into computers, mobile phones, televisions, webcams, video streams, and more.</p>
              <br/>
			  <p>here's the list of charges against him:<ul>
                <li>illegal gathering of national defense information,</li>
                <li>illegal transmission of lawfully possessed national defense information,</li>
                <li>illegal transmission of unlawfully possessed national defense information,</li>
                <li>unauthorized access to a computer to obtain classified information,</li>
                <li>theft of Government property,</li>
                <li>unauthorized access of a computer to obtain information from a Department or Agency of the United States,</li>
                <li>causing transmission of a harmful computer program, information, code, or command,</li>
                <li>making material false statements to representatives of the FBI,</li>
                <li>obstruction of justice</li>
                <li>receipt of child pornography,</li>
                <li>possession of child pornography,</li>
                <li>transportation of child pornography, and</li>
                <li>copyright infringement.</li>
                
              </ul>
              <h2></h2>
              <h3></h3>
              
              <button class="btn default-btn">Home</button>
              <button class="btn btn-red">Smartphone</button>
              <button class="btn btn-yellow">Computers</button>
              
             
            </div>
            <div class="social_link">
              <ul class="sociallink_nav">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
              </ul>
            </div>
            
          </div>
        </div>
      </div>
      <nav class="nav-slit"> <a class="prev" href="#"> <span class="icon-wrap"><i class="fa fa-angle-left"></i></span>
        <div>
          <h3>City Lights</h3>
          <img src="../images/post_img1.jpg" alt=""/> </div>
        </a> <a class="next" href="#"> <span class="icon-wrap"><i class="fa fa-angle-right"></i></span>
        <div>
          <h3>Street Hills</h3>
          <img src="../images/post_img1.jpg" alt=""/> </div>
        </a> </nav>
      <div class="col-lg-4 col-md-4 col-sm-4">
        <aside class="right_content">
          <?php include'common/popular.php';?>
          <div class="single_sidebar">
            <ul class="nav nav-tabs" role="tablist">
              <li role="presentation" class="active"><a href="#category" aria-controls="home" role="tab" data-toggle="tab">Category</a></li>
              <li role="presentation"><a href="#video" aria-controls="profile" role="tab" data-toggle="tab">Video</a></li>
            </ul>
            <div class="tab-content">
              <div role="tabpanel" class="tab-pane active" id="category">
                <ul>
                  <li class="cat-item"><a href="#">Sports</a></li>
                  <li class="cat-item"><a href="#">Fashion</a></li>
                  <li class="cat-item"><a href="#">Business</a></li>
                  <li class="cat-item"><a href="#">Technology</a></li>
                  <li class="cat-item"><a href="#">Games</a></li>
                  <li class="cat-item"><a href="#">Life &amp; Style</a></li>
                  <li class="cat-item"><a href="#">Photography</a></li>
                </ul>
              </div>
              <?php include'common/video.php';?>
         
            </div>
          </div>
          
          <div class="single_sidebar wow fadeInDown">
            <h2><span>Category Archive</span></h2>
            <select class="catgArchive">
              <option>Select Category</option>
              <option>Life styles</option>
              <option>Sports</option>
              <option>Technology</option>
              <option>Treads</option>
            </select>
          </div>
          <div class="single_sidebar wow fadeInDown">
            <h2><span>Links</span></h2>
            
          </div>
        </aside>
      </div>
    </div>
  </section>
  <?php include'common/footer.php';?>
</div>
<script src="../assets/js/jquery.min.js"></script> 
<script src="../assets/js/wow.min.js"></script> 
<script src="../assets/js/bootstrap.min.js"></script> 
<script src="../assets/js/slick.min.js"></script> 
<script src="../assets/js/jquery.li-scroller.1.0.js"></script> 
<script src="../assets/js/jquery.newsTicker.min.js"></script> 
<script src="../assets/js/jquery.fancybox.pack.js"></script> 
<script src="../assets/js/custom.js"></script>
</body>
</html>