<html>
<?php include'common/head.php';?>
<body>
<?php include'common/nav.php';?>
  <section id="contentSection">
  <section id="contentSection">
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-8">
        <div class="left_content">
          <div class="single_page">
            <ol class="breadcrumb">
              <li><a href="../index.php">Home</a></li>
              
            </ol>
            <h1>WhatsApp to offer 24-hr customer support for payments services in India</h1>
            <div class="post_commentbox"> <a href="#"><i class="fa fa-user"></i>Technews</a> <span><i class="fa fa-calendar"></i></span> <a href="#"><i class="fa fa-tags"></i>Technology</a> </div>
            <div class="single_page_content"> <img class="img-center" src="../images/24.jpg" alt="">
    <p>WhatsApp is working on setting up a 24-hour customer support for users of its payments services that is slated to be rolled out in India in the coming week.<br/>
	WhatsApp is working on setting up a 24-hour customer support for users of its payments services that is slated to be rolled out in India in the coming weeks. WhatsApp, which has over 200 million users in India, will provide support through e-mails as well as a toll-free number.

“We will provide 24-hour customer support. Payments users can contact the support team via e-mail and a toll-free number (when the service is rolled out in India),” a WhatsApp spokesperson told PTI. The spokesperson added that the support will be available in English as well as three Indian languages — Hindi, Marathi and Gujarati. However, the official declined to comment on the launch dates and other details
While WhatsApp is yet to announce the official date of launch of its UPI-based payments service, industry watchers expect an announcement to come in the next few weeks. Almost one million people are “testing” WhatsApp’s payments service in India, which is the largest base for the Facebook-owned company that has over 1.5 billion users globally. WhatsApp payment service, which rivals the likes of Paytm, has been in beta testing in India over the last few months.

The Facebook-owned company is also updating its terms of service and privacy policy for users to “reflect the addition of payment interoperability features” ahead of the full-fledged launch of the service. The spokesperson said WhatsApp has worked closely with National Payments Corporation of India (NPCI), bank partners, and the Indian government on the details of how its service works.
Under the updated terms, WhatsApp states that it will not provide refunds or facilitate chargebacks as once a user submits a payment, it is final. “WhatsApp is not liable for unauthorised transactions. We assume no responsibility for the underlying transaction of funds, or the actions or identity of any transfer recipient or sender,” it adds.

The spokesperson explained that while users can connect with WhatsApp for queries related to the payments offering, they would have to reach out to their banks for any dispute resolution




.</p>
             
            </div>
            <div class="social_link">
              <ul class="sociallink_nav">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
              </ul>
            </div>
            
          </div>
        </div>
      </div>
      <nav class="nav-slit"> <a class="prev" href="#"> <span class="icon-wrap"><i class="fa fa-angle-left"></i></span>
        <div>
          <h3>City Lights</h3>
          <img src="../images/post_img1.jpg" alt=""/> </div>
        </a> <a class="next" href="#"> <span class="icon-wrap"><i class="fa fa-angle-right"></i></span>
        <div>
          <h3>Street Hills</h3>
          <img src="../images/post_img1.jpg" alt=""/> </div>
        </a> </nav>
      <div class="col-lg-4 col-md-4 col-sm-4">
        <aside class="right_content">
          <?php include'common/popular.php';?>
          <div class="single_sidebar">
            <ul class="nav nav-tabs" role="tablist">
              <li role="presentation" class="active"><a href="#category" aria-controls="home" role="tab" data-toggle="tab">Category</a></li>
              <li role="presentation"><a href="#video" aria-controls="profile" role="tab" data-toggle="tab">Video</a></li>
            </ul>
            <div class="tab-content">
              <div role="tabpanel" class="tab-pane active" id="category">
                <ul>
                  <li class="cat-item"><a href="#">Sports</a></li>
                  <li class="cat-item"><a href="#">Fashion</a></li>
                  <li class="cat-item"><a href="#">Business</a></li>
                  <li class="cat-item"><a href="#">Technology</a></li>
                  <li class="cat-item"><a href="#">Games</a></li>
                  <li class="cat-item"><a href="#">Life &amp; Style</a></li>
                  <li class="cat-item"><a href="#">Photography</a></li>
                </ul>
              </div>
              <?php include'common/video.php';?>
            </div>
          </div>
         
          <div class="single_sidebar wow fadeInDown">
            <h2><span>Category Archive</span></h2>
            <select class="catgArchive">
              <option>Select Category</option>
              <option>Life styles</option>
              <option>Sports</option>
              <option>Technology</option>
              <option>Treads</option>
            </select>
          </div>
          <div class="single_sidebar wow fadeInDown">
            <h2><span>Links</span></h2>
            
          </div>
        </aside>
      </div>
    </div>
  </section>
  <?php include'common/footer.php';?>
</div>
<script src="../assets/js/jquery.min.js"></script> 
<script src="../assets/js/wow.min.js"></script> 
<script src="../assets/js/bootstrap.min.js"></script> 
<script src="../assets/js/slick.min.js"></script> 
<script src="../assets/js/jquery.li-scroller.1.0.js"></script> 
<script src="../assets/js/jquery.newsTicker.min.js"></script> 
<script src="../assets/js/jquery.fancybox.pack.js"></script> 
<script src="../assets/js/custom.js"></script>
</body>
</html>