
<a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
<div class="container">
  <header id="header">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12">
        <div class="header_top">
          <div class="header_top_left">
            <ul class="top_nav">
              <li><a href="index.php">Home</a></li>
              
              <li><a href="pages/contact.php">Contact</a></li>
                 <li><a href="pages/index1.html">Motivational photos</a></li>
                 <li><a href="pages/games/new34.html">Games</a></li>
            </ul>
          </div>
          <div class="header_top_right">
            <p><?php echo date("D M d, Y G:i a"); ?></p>
          </div>
        </div>
      </div>
      <div class="col-lg-12 col-md-12 col-sm-12">
        <div class="header_bottom">
          <div class="logo_area"><a href="index.php" class="logo"><img src="images/logo.jpg" alt=""></a></div>
          <div class="add_banner"><a href="#"><img src="" alt=""></a></div>
        </div>
      </div>
    </div>
  </header>
  <section id="navArea">
    <nav class="navbar navbar-inverse" role="navigation">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      </div>
      <div id="navbar" class="navbar-collapse collapse">
        <ul class="nav navbar-nav main_nav">
          <li class="active"><a href="index.php"><span class="fa fa-home desktop-home"></span><span class="mobile-show">Home</span></a></li>
          <li><a href="pages/index1.html">Motivational photos</a></li>

         
          <li><a href="pages/contact.php">Contact Us</a></li>
          
        </ul>
      </div>
    </nav>
  </section>
  <section id="newsSection">
    <div class="row">
      <div class="col-lg-12 col-md-12">
        <div class="latest_newsarea"> <span>Latest News</span>
          <ul id="ticker01" class="news_sticker">
            <li><a href="pages/23.php"><img src="images/th.jpg" alt="">Fajita heist: Texas man sentenced to 50 years for stealing $1.2 million worth of food</a></li>
            <li><a href="pages/22.php"><img src="images/1.jpg" alt="">Hackers Who Hit Olympics 2018 Arw Still Alive and Kicking</a></li>
            <li><a href="pages/3.php"><img src="images/2.jpg" alt="">Ex cia employee charged with leaking 'Vault 7' hacking tools to Wikileaks</a></li>
            <li><a href="pages/4.php"><img src="images/3.jpg" alt="">Were real dinosaurs as bulletproof as the one in Jurassic World: Fallen Kingdom? </a></li>
            <li><a href="pages/6.php"><img src="images/4.jpg" alt="">PUBG for Android: News, rumors, updates, and tips for winning!</a></li>
            <li><a href="pages/7.php"><img src="images/5.jpg" alt="">things you must  know about the FIFA World Cup 2018</a></li>
            <li><a href="pages/8.php"><img src="images/7.jpg" alt="">Trump like to have a 'Space Force,' for america or did USA Already Has One?</a></li>
            <li><a href="pages/9.php"><img src="images/8.jpg" alt="">cash worth INR 1.2 million in an ATM get chewed by rodents</a></li>
            <li><a href="pages/10.php"><img src="images/9.jpeg" alt="">now  Blind will be able to See With Their Tongues</a></li>
            <li><a href="pages/11.php"><img src="images/10.png" alt="">Snake Robots: Watch This Without Squirming?</a></li>
            <li><a href="pages/12.php"><img src="images/11.jpg" alt="">now robots can ‘read’ your mind but can you?</a></li>
          </ul>
          <div class="social_area">
            <ul class="social_nav">
              
              
              <li class="mail"><a href="goluiswow@gmail.com"></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>