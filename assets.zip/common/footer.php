  <footer id="footer">
    <div class="footer_top">
      <div class="row">
        <div class="col-lg-4 col-md-4 col-sm-4">
          <div class="footer_widget wow fadeInLeftBig">
            <h2>Why my website for news</h2>
            <p>Honesty and integrity are absolutely essential for success in life - all areas of life.<br/>
            The really good news is that anyone can develop both honesty and integrity.</p>
            <br/>
            <p>Good news is rare these days, and every glittering ounce of it should be<br/>
            cherished and hoarded and worshipped and fondled like a priceless diamond.</p>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-4">
          <div class="footer_widget wow fadeInDown">
           <h2>What is fact?</h2>
           <p>A fact is a statement that is consistent with reality or can be proven with evidence.<br/> The usual test for a statement of fact is verifiability — that is, whether it can be demonstrated to <br/>
           correspond to experience. Standard reference works are often used to check facts.</p>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-4">
          <div class="footer_widget wow fadeInRightBig">
            <h2>Contact</h2>
            <p>princerajput834001@gmail.com</p>
            <address>
			kanout place , Delhi
            INDIA
            </address>
          </div>
        </div>
      </div>
    </div>
    <div class="footer_bottom">
      <p class="copyright">Copyright <a href="index.html">Sabsacademy</a></p>
      <p class="developer">Developed By Prince raj</p>
    </div>
  </footer>