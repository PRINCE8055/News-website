 <div role="tabpanel" class="tab-pane" id="video">
                <div class="vide_area">
                  <iframe width="100%" height="315" src="https://www.youtube.com/embed/2RIyTXe8A8I" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                </div>
				<div class="vide_area">
<iframe width="100%" height="315" src="https://www.youtube.com/embed/I5thcGugPaE" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>                </div>
				<div class="vide_area">
<iframe width="100%" height="315" src="https://www.youtube.com/embed/349dlxLVq5g" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
</div>
              </div>