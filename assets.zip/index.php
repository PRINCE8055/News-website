<!DOCTYPE html>
<html>
    <meta name="google-site-verification" content="65kobWidO3idLB_RL_4QdYJqFQ6j5Ip-VwsI4fTwII0" />
<?php include'common/head.php';?>
<body>
<?php include'common/nav.php';?>
  <section id="sliderSection"><meta name="google-site-verification" content="65kobWidO3idLB_RL_4QdYJqFQ6j5Ip-VwsI4fTwII0" />
      
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-8">
        <div class="slick_slider">
            <div class="single_iteam"> <a href="pages/2.php"> <img src="images/2.jpg" alt=""></a>
            <div class="slider_article">
              <h2><a class="slider_tittle" href="pages/2.php">Ex cia employee charged with leaking 'Vault 7' hacking tools to Wikileaks</a></h2>
              <p>A 29-year-old former CIA computer programmer who was charged with possession of child pornography last year has now been charged with masterminding the largest leak of classified information in the agency's history....</p>
            </div>
          </div>
             <div class="single_iteam"> <a href="pages/13.php"> <img src="images/131.png" alt=""></a>
            <div class="slider_article">
              <h2><a class="slider_tittle" href="pages/13.php">Thousands of Mobile Apps Expose Their Unprotected Firebase Hosted Databases</a></h2>
              <p>.<br/>
</p>
            </div>
          </div>   
            <div class="single_iteam"> <a href="pages/12.php"> <img src="images/12.jpg" alt=""></a>
            <div class="slider_article">
              <h2><a class="slider_tittle" href="pages/12.php">SUMMER SOLSTICE:longest day of the year</a></h2>
              <p>.<br/>
</p>
            </div>
          </div>  
          <div class="single_iteam"> <a href="pages/11.php"> <img src="images/th.jpg" alt=""></a>
            <div class="slider_article">
              <h2><a class="slider_tittle" href="pages/11.php">Fajita heist: Texas man sentenced to 50 years for stealing $1.2 million worth of food</a></h2>
              <p>.<br/>
</p>
            </div>
          </div>

          <div class="single_iteam"> <a href="pages/single_page.php"> <img src="images/1.jpg" alt=""></a>
            <div class="slider_article">
              <h2><a class="slider_tittle" href="pages/single_page.php">Hackers Who Hit Olympics 2018 Arw Still Alive and Kicking</a></h2>
              <p>The group behind it is still alive, kicking and has now been found targeting biological and chemical threat prevention laboratories in Europe and Ukraine, and a few financial organisation in Russia.<br/>
</p>
            </div>
          </div>
          <div class="single_iteam"> <a href="pages/2.php"> <img src="images/2.jpg" alt=""></a>
            <div class="slider_article">
              <h2><a class="slider_tittle" href="pages/2.php">Ex cia employee charged with leaking 'Vault 7' hacking tools to Wikileaks</a></h2>
              <p>A 29-year-old former CIA computer programmer who was charged with possession of child pornography last year has now been charged with masterminding the largest leak of classified information in the agency's history....</p>
            </div>
          </div>
          <div class="single_iteam"> <a href="pages/3.php"> <img src="images/3.jpg" alt=""></a>
            <div class="slider_article">
              <h2><a class="slider_tittle" href="pages/3.php">Were real dinosaurs as bulletproof as the one in Jurassic World: Fallen Kingdom? </a></h2>
              <p>“I guess that depends on what kinds of bullets you’re shooting at them”</p>
            </div>
          </div>
		  <div class="single_iteam"> <a href="pages/4.php"> <img src="images/4.jpg" alt=""></a>
            <div class="slider_article">
              <h2><a class="slider_tittle" href="pages/4.php">PUBG for Android: News, rumors, updates, and tips for winning! </a></h2>
              <p>The latest update to PUBG Mobile has introduced a slew of features that have made the best shooter for Android even better. You can find the full list of new features in the "What's New" section of its Google Play Store listing, but I'll highlight the most significant improvements to the game:</p>
            </div>
          </div>
		  <div class="single_iteam"> <a href="pages/5.php"> <img src="images/5.jpg" alt=""></a>
            <div class="slider_article">
              <h2><a class="slider_tittle" href="pages/5.php">things you must  know about the FIFA World Cup 2018 </a></h2>
              <p>Here are some interesting facts for fans travelling for the “world’s most-viewed sporting event”, which will be hosted for the very first time by Russia. </p>
          </div>
		  </div> <div class="single_iteam"> <a href="pages/6.php"> <img src="images/7.jpg" alt=""></a>
            <div class="slider_article">
              <h2><a class="slider_tittle" href="pages/6.php">  Trump like to have  a 'Space Force,' for america or did USA Already Has One? </a></h2>
              <p> A Space Force, presumably, would take charge of protecting and maintaining America's space capabilities.. </p>
          </div>
		  </div> <div class="single_iteam"> <a href="pages/7.php"> <img src="images/8.jpg" alt=""></a>
            <div class="slider_article">
              <h2><a class="slider_tittle" href="pages/7.php">cash worth INR 1.2 million in an ATM get chewed by rodents</a></h2>
              <p> "When the engineer and other officials opened the ATM on June 11, they found destroyed notes and also found a dead mouse inside the ATM," the superintendent said.. </p>
          </div>
		  </div> <div class="single_iteam"> <a href="pages/8.php"> <img src="images/9.jpeg" alt=""></a>
            <div class="slider_article">
              <h2><a class="slider_tittle" href="pages/8.php">now  Blind will be able to  See With Their Tongues</a></h2>
              <p>Technology, for me, it’s giving something back to somebody who was taken out of humanity.” – Andy Fabino  </p>
          </div>
		  </div><div class="single_iteam"> <a href="pages/9.php"> <img src="images/10.png" alt=""></a>
            <div class="slider_article">
              <h2><a class="slider_tittle" href="pages/9.php">Snake Robots: Watch This Without Squirming?</a></h2>
              <p>Technology, for me, it’s giving something back to somebody who was taken out of humanity.” – Andy Fabino  </p>
          </div>
		  </div><div class="single_iteam"> <a href="pages/10.php"> <img src="images/11.jpg" alt=""></a>
            <div class="slider_article">
              <h2><a class="slider_tittle" href="pages/10.php">now robots can ‘read’ your mind but can you?</a></h2>
              <p>Directing bots with brain waves and muscle twitches could make for a speedier response time </p>
          </div>
		  </div>
          
        </div>
      </div>
      <div class="col-lg-4 col-md-4 col-sm-4">
       <?php include'common/latest.php';?>
      </div>
    </div>
  </section>
  <section id="contentSection">
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-8">
        <div class="left_content">
          <div class="single_post_content">
            <h2><span>Technology and Science news</span></h2>
            <div class="single_post_content_left">
              <ul class="business_catgnav  wow fadeInDown">
                <li>
                  <figure class="bsbig_fig"> <a href="pages/141.php" class="featured_img"> <img alt="" src="images/14.jpg"  height="190"> <span class="overlay"></span> </a>
                    <figcaption> <a href="pages/141.php">SpaceX to launch its Dragon spacecraft on 29 June for a re-supply mission to the ISS</a> </figcaption>
<p>NASA's commercial cargo provider SpaceX is set to launch its 15th re-supply mission to the International Space Station (ISS) on June 29, the US space agency said.<br/>
The SpaceX Falcon 9 rocket, with the Dragon spacecraft onboard. Reuters. </p>                  </figure>
                </li>
              </ul>
            </div>
			<div class="single_post_content_right">
              <ul class="business_catgnav  wow fadeInDown">
                <li>
                  <figure class="bsbig_fig"> <a href="pages/15.php" class="featured_img"> <img alt="" src="images/15.jpg"> <span class="overlay"></span> </a>
                    <figcaption> <a href="pages/15.php">Apple finally admits that the 'Butterfly switch' MacBook keyboard is defective </a> </figcaption>
<p>After months, and possibly years, of pretending that nothing was wrong, Apple has finally acknowledged that the keyboard on its new MacBooks and MacBook Pros were defective.</p>                </li>
              </ul>
            </div>
			<div class="single_post_content_left">
              <ul class="business_catgnav  wow fadeInDown">
                <li>
                  <figure class="bsbig_fig"> <a href="pages/16.php" class="featured_img"> <img alt="" src="images/16.jpg"> <span class="overlay"></span> </a>
                    <figcaption> <a href="pages/16.php">The Asus ROG Phone might make its way to India by September this year</a> </figcaption>
<p>TThe Asus ROG Phone was announced at Computex 2018 and it is one of the few devices that panders to a niche, hard-core audience interested in gaming on a smartphone. Before the ROG Phone, it was the Razer Phone and the Xiaomi BlackShark.</p>    
</ul>
            </div>
            <div class="single_post_content_right">
              <ul class="spost_nav">
                <li>
                  <div class="media wow fadeInDown"> <a href="pages/17.php" class="media-left"> <img alt="" src="images/17.jpg">NASA’s Curiosity manages a quick selfie just before the great Martian dust storm </a>
                    <div class="media-body"> <a href="pages/17.php" class="catg_title">    <p>NASA’s Opportunity rover has suspended all its science operations on Mars following a storm of dust particles. The storm started about two weeks ago and has been growing, and has engulfed much of Mars.
 </p> </div>
                  </div>
                </li>
                <li>
                  <div class="media wow fadeInDown"> <a href="pages/18.php" class="media-left"> <img alt="" src="images/18.jpg"> </a>
                    <div class="media-body"> <a href="pages/18.php" class="catg_title">Yamaha R15 V3.0 MotoGP edition with custom livery is coming to India in August</a>
					<p>If you’ve been lusting after the Yamaha R15 for a while, you might want to wait just a little bit longer. A recent report reveals that the MotoGP edition of the R15 V3.0 is coming to India this August.
					</p> </div>
                  </div>
                </li>
               
                
              </ul>
            </div>
          </div>
          <div class="fashion_technology_area">
            <div class="fashion">
              <div class="single_post_content">
                <h2><span>Lifestyle</span></h2>
                <ul class="business_catgnav wow fadeInDown">
                  <li>
                    <figure class="bsbig_fig"> <a href="pages/19.php" class="featured_img"> <img alt="" src="images/19.jpg"> <span class="overlay"></span> </a>
                      <figcaption> <a href="pages/19.php">Shraddha Kapoor or Gigi Hadid: Who wore the lemon yellow Prabal Gurung outfit better?</a> </figcaption>
                      <p>It might be an inspiration from an earlier style statement or a mere coincidence,<br/> but whenever celebrities step out wearing similar outfits, comparisons are inevitable. Recently, <br/>Shraddha Kapoor made an appearance in a lemon yellow outfit from designer Prabal Gurung, a piece quite similar to the one we had seen model Gigi Hadid don some time back.</p>
                    </figure>
                  </li>
                </ul>
                <ul class="spost_nav">
                  <li>
                    <div class="media wow fadeInDown"> <a href="pages/20.php" class="media-left"> <img alt="" src="images/20.jpg"> </a>
                      <div class="media-body"> <a href="pages/20.php" class="catg_title">Kit Harington-Rose Leslie wedding: Sophie Turner channels her inner rock star, Emilia Clarke plays it safe</a> </div>
                    </div>
                  </li>
                  <li>
                    <div class="media wow fadeInDown"> <a href="pages/21.php" class="media-left"> <img alt="" src="images/21.jpg"> </a>
                      <div class="media-body"> <a href="pages/21.php" class="catg_title">LHow to pick the most genuine pair of leather shoes</a> </div>
                    </div>
                  </li>
                  <li>
                    <div class="media wow fadeInDown"> <a href="pages/22.php" class="media-left"> <img alt="" src="images/23.jpeg"> </a>
                      <div class="media-body"> <a href="pages/22.php" class="catg_title">ver Wondered What Happens to the Clothes that Actors Wear in Movies?</a> </div>
                    </div>
                  </li>
                 
                </ul>
              </div>
            </div>
            <div class="technology">
              <div class="single_post_content">
                <h2><span>Technology</span></h2>
                <ul class="business_catgnav">
                  <li>
                    <figure class="bsbig_fig wow fadeInDown"> <a href="pages/23.php" class="featured_img"> <img alt="" src="images/22.jpg"> <span class="overlay"></span> </a>
                      <figcaption> <a href="pages/23.php">Samsung is working on a bezel-less smartphone with two screens, according to a patent which was filed in 2016, and has just been granted by the United States Patent & Trademark Office (USPTO) (via MobielKopen).</a> </figcaption>
                      <p>The patent application shows a smartphone with a bezel-less display, and a secondary display on the back. The concept of having a secondary display on the rear is nothing new. We’ve already seen the implementation of a secondary screen on the back with the YotaPhone and Meizu Pro 7. A display on the rear of the phone is an interesting idea, <br/></p>
                    </figure>
                  </li>
                </ul>
                <ul class="spost_nav">
                  <li>
                    <div class="media wow fadeInDown"> <a href="pages/24.php" class="media-left"> <img alt="" src="images/241.jpg"> </a>
                      <div class="media-body"> <a href="pages/24.php" class="catg_title"> WhatsApp to offer 24-hr customer support for payments services in India</a> </div>
                    </div>
                  </li>
                  <li>
                    <div class="media wow fadeInDown"> <a href="pages/25.php" class="media-left"> <img alt="" src="images/25.jpg"> </a>
                      <div class="media-body"> <a href="pages/25.php" class="catg_title">Microsoft News for Android, iOS, Windows 10 is here</a> </div>
                    </div>
                  </li>
                  <li>
                    <div class="media wow fadeInDown"> <a href="pages/26.php" class="media-left"> <img alt="" src="images/26.jpg"> </a>
                      <div class="media-body"> <a href="pages/26.php" class="catg_title">How to text from your computer with Android Messages</a> </div>
                    </div>
                  </li>
                  
               
                    
                </ul>
              </div>
            </div>
          </div>
          <div class="single_post_content">
            <h2><span>Photography</span></h2>
            <ul class="photograph_nav  wow fadeInDown">
              <li>
                <div class="photo_grid">
                  <figure class="effect-layla"><img src="images/photo1.jpg" alt=""/> </figure>
                </div>
              </li>
              <li>
                <div class="photo_grid">
                  <figure class="effect-layla"><img src="images/photo2.jpg" alt=""/> </figure>
                </div>
              </li>
              <li>
                <div class="photo_grid">
                  <figure class="effect-layla"><img src="images/photo3.jpg" alt=""/> </figure>
                </div>
              </li>
              <li>
                <div class="photo_grid">
                  <figure class="effect-layla"> <img src="images/tech5.jpg" alt=""/></figure>
                </div>
              </li>
              <li>
                <div class="photo_grid">
                  <figure class="effect-layla"> <img src="images/photo6.jpg" alt=""/> </figure>
                </div>
              </li>
              <li>
                <div class="photo_grid">
                  <figure class="effect-layla"> <img src="images/photo7.jpg" alt=""/> </figure>
                </div>
              </li>
            </ul>
          </div>
          <div class="single_post_content">
            <h2><span>Sports</span></h2>
            <div class="single_post_content_left">
              <ul class="business_catgnav">
                <li>
                  <figure class="bsbig_fig  wow fadeInDown"> <a class="featured_img" href="pages/27.php"> <img src="images/27.jpg" alt=""> <span class="overlay"></span> </a>
                    <figcaption> <a href="pages/27.php">India stun Argentina, continue unbeaten run in Champions Trophy</a> </figcaption>
<p>	India continued their unbeaten run in the Champions Trophy hockey tournament and surprised Olympic champions Argentina 2-1 for a second consecutive win in the 37th and last edition of the prestigious tournament in Breda on Sunday.
</p>                 </figure>
                </li>
              </ul>
            </div>
            <div class="single_post_content_right">
              <ul class="spost_nav">
                <li>
                  <div class="media wow fadeInDown"> <a href="pages/28.php" class="media-left"> <img alt="" src="images/28.jpg"> </a>
                    <div class="media-body"> <a href="pages/28.php" class="catg_title">cSchedule: FIFA World Cup 2018</a> </div>
                  </div>
                </li>
                <li>
                  <div class="media wow fadeInDown"> <a href="pages/29.php" class="media-left"> <img alt="" src="images/29.jpg"> </a>
                    <div class="media-body"> <a href="pages/29.php" class="catg_title"> 'Kohli panicked while preparing for England tour</a> </div>
                  </div>
                </li>
                <li>
                  <div class="media wow fadeInDown"> <a href="pages/30.php" class="media-left"> <img alt="" src="images/games5.jpg"> </a>
                    <div class="media-body"> <a href="pages/30.php" class="catg_title"> Deontay Wilder ready to make sacrifices to ensure Anthony Joshua unification figh</a> </div>
                  </div>
                </li>
                
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-4 col-sm-4">
        <aside class="right_content">
         <?php include'common/popular.php';?>
          <div class="single_sidebar">
            <ul class="nav nav-tabs" role="tablist">
              <li role="presentation" class="active"><a href="#category" aria-controls="home" role="tab" data-toggle="tab">Category</a></li>
              <li role="presentation"><a href="#video" aria-controls="profile" role="tab" data-toggle="tab">Video</a></li>
            </ul>
            <div class="tab-content">
              <div role="tabpanel" class="tab-pane active" id="category">
                <ul>
                  <li class="cat-item"><a href="pages/28.php">Sports</a></li>
                  <li class="cat-item"><a href="pages/22.php">Fashion</a></li>
                  <li class="cat-item"><a href="pages/17.php">business</a></li>
                  <li class="cat-item"><a href="pagse/19.php">Technology</a></li>
                  <li class="cat-item"><a href="pages/29.php">Games</a></li>
                 
                </ul>
              </div>
             <?php include'common/video.php';?>
              
            </div>
          </div>

          <div class="single_sidebar wow fadeInDown">
          
          <div class="single_sidebar wow fadeInDown">
            
            
          </div>
        </aside>
      </div>
    </div>
  </section>
<?php include'common/footer.php';?>
</div>
<script src="assets/js/jquery.min.js"></script> 
<script src="assets/js/wow.min.js"></script> 
<script src="assets/js/bootstrap.min.js"></script> 
<script src="assets/js/slick.min.js"></script> 
<script src="assets/js/jquery.li-scroller.1.0.js"></script> 
<script src="assets/js/jquery.newsTicker.min.js"></script> 
<script src="assets/js/jquery.fancybox.pack.js"></script> 
<script src="assets/js/custom.js"></script>
</body>
</html>