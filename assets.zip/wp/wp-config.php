<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'sabsacad_wp303');

/** MySQL database username */
define('DB_USER', 'sabsacad_wp303');

/** MySQL database password */
define('DB_PASSWORD', '0Sr9b)-1Lp');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'n4lufnhj7jfyifiavzts50q4xrxughf05i0onqvpwr9y723pgmpexrwdire0z1vw');
define('SECURE_AUTH_KEY',  'fnq5b7za2yfberwxrfkmai9lxstacummsezz1mlms0kvsgf8x9ahyhkmgwcyrjor');
define('LOGGED_IN_KEY',    'nw59ld20uz1aq0u0czyan1xr1tbl5oncgxhnquwkm9r1da0eyf53wevjxvzyfnja');
define('NONCE_KEY',        '611ix0vlwnc3yj9q4zoewqr06ric3jex9p6deja2kochpe0kaigzlgcfga8jeq5z');
define('AUTH_SALT',        '4hymp4kalbdys4vdk5l2vfrwh1qpiiwuwmjobyyrf56feslkpfhmhljhyohwuv9f');
define('SECURE_AUTH_SALT', 'gtctbqgrw0wuqrredks4o8xf0yydjvrcan1miqoia2n6kidkeau5zgxx0py56hc8');
define('LOGGED_IN_SALT',   'comlfuyxwbcu0agp1v0zgwk8z3kpyminvns3lqdjefpujwotjtzp6jwgwsjovwbb');
define('NONCE_SALT',       'xjjctrijc8jttbgvlwfzbdymv11ueflier00z4q1rzjgbia9skgfuv7t3nltzw7s');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wpxc_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
